package hr.java.production.main;

import hr.java.restaurant.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

import static hr.java.restaurant.model.Meal.highCalorieMeal;
import static hr.java.restaurant.model.Meal.printMeals;

public class Main {

    public static Logger log = LoggerFactory.getLogger(Main.class.getName());

    /**
     * Ovo je metoda main u klasi Main, pokreće program i traži upise svih podataka za restoran
     *
     * @param args
     */
    public static void main(String[] args) {


        log.info("Starting application...");
        log.warn("Warning message");
        log.error("Error message.");
        log.debug("Debug message.");

        Scanner sc = new Scanner(System.in);

        Category[] categories = new Category[3];
        Set<Ingredient> ingredients = new HashSet<>();
        Set<Meal> meals = new HashSet<>();
        Set<Chef> chefs = new HashSet<>();
        Set<Waiter> waiters = new HashSet<>();
        Set<Deliverer> deliverers = new HashSet<>();
        Restaurant[] restaurants = new Restaurant[3];
        Address[] addresses = new Address[3];
        Order[] orders = new Order[3];

        Map<Meal, List<Restaurant>> mealsInRestaurant = new HashMap<>();

        for (Restaurant restaurant : restaurants) {
            for (Meal meal : restaurant.getMeals()) {
                mealsInRestaurant.computeIfAbsent(meal, k -> new ArrayList<>()).add(restaurant);
            }
        }

        Category.inputCategory(categories, sc);
        Ingredient.inputIngredient(ingredients, categories, sc);
        Meal.inputMeal(meals, categories, ingredients, sc);
        Chef.inputChef(chefs, sc);
        Waiter.inputWaiter(waiters, sc);
        Deliverer.inputDeliverer(deliverers, sc);
        Restaurant.inputRestaurant(restaurants, meals, chefs, waiters, deliverers, sc);
        Order.inputOrder(orders, restaurants, meals, chefs, deliverers, sc);


        System.out.println("Pick a meal:");
        List<Meal> mealList = new ArrayList<>(meals);
        for (int i = 0; i < mealList.size(); i++) {
            System.out.println((i + 1) + ". " + mealList.get(i).getName());
        }

        int choice = sc.nextInt();
        if (choice < 1 || choice > mealList.size()) {
            System.out.println("Enter a valid index!");
        } else {
            Meal selectedMeal = mealList.get(choice - 1);
            List<Restaurant> availableRestaurants = mealsInRestaurant.get(selectedMeal);

            if (availableRestaurants == null || availableRestaurants.isEmpty()) {
                System.out.println("None of restaurants have this meal.");
            } else {
                System.out.println("Restaurants that have " + selectedMeal.getName() + ":");
                for (Restaurant restaurant : availableRestaurants) {
                    System.out.println("- " + restaurant.getName());
                }
            }
        }

        /*List<Restaurant> lambdaRestaurants = new ArrayList<>();
        for (Restaurant restaurant : restaurants) {
            lambdaRestaurants.add(restaurant);
        }

        lambdaRestaurants.sort((r1, r2) -> r1.getName().compareTo(r2.getName()));

        Restaurant restaurantWithMostEmployees = lambdaRestaurants.stream().
                max(Comparator.comparingInt(r ->
                        r.getChefs().size()
                        + r.getWaiters().size()
                        + r.getDeliverers().size())).orElse(null);

    }

    Map<Meal, Integer> mealOrders = new HashMap<>();
    Meal mostOrderedMeal = mealOrders.entrySet().stream()
            .max(Comparator.comparingInt(Map.Entry::getValue))
            .map(Map.Entry::getKey).orElse(null);
    */

        List<Meal> highCalorieMeals = highCalorieMeal((List<Meal>) meals);
        printMeals(highCalorieMeals);
    }
}