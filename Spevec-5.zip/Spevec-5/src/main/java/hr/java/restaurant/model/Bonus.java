package hr.java.restaurant.model;

import java.math.BigDecimal;

/**
 * Zapis (record) koji predstavlja bonus na plaći zaposlenika
 * @param amount  - koliki bonus će zaposlenik dobiti
 */
public record Bonus(BigDecimal amount) {

    /**
     * Konstruktor za izradu objekta tipa Bonus
     * @param amount - iznos bonusa
     */
    public Bonus(BigDecimal amount)
    {
        this.amount = amount;
    }

    public BigDecimal getAmount() {
        return amount;
    }
}
