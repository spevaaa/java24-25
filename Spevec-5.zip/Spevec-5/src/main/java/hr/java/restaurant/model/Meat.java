package hr.java.restaurant.model;

/**
 * Zapečaćeno sučelje koje predstavlja meso
 * Saddrži dvije metode za dobivanje vrste mesa i metode kuhanja jela.
 */
public sealed interface Meat permits MeatDish{
    String getMeatType();
    String getCookingMethod();
}
