package hr.java.restaurant.generics;

import hr.java.restaurant.model.Restaurant;

import java.util.List;

public class RestaurantLabourExchangeOffice<T extends Restaurant> {
    private List<T> restaurantList;

    public RestaurantLabourExchangeOffice(List<T> restaurantList) {
        this.restaurantList = restaurantList;
    }

    public List<T> getRestaurantList() {
        return restaurantList;
    }

    public void setRestaurantList(List<T> restaurantList) {
        this.restaurantList = restaurantList;
    }
}
