package hr.java.restaurant.model;
import hr.java.restaurant.exception.DuplicateEntityException;

import hr.java.utils.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Scanner;
import java.util.Set;

/**
 * Klasa Restaurant koja predstavlja restorane.
 * Sadrži ime restorana, adresu restorana, polje jela koje imaju u ponudi,
 * kuhare, konobare i dostavljače.
 */
public class Restaurant extends Entity {

    private static Logger log = LoggerFactory.getLogger(Restaurant.class);

    private String name;
    private Address address;
    private Set<Meal> meals;
    private Set<Chef> chefs;
    private Set<Waiter> waiters;
    private Set<Deliverer> deliverers;

    /**
     * Konstruktor za kreiranje objekta tipa Restaurant
     * @param id - predstavlja ID restorana
     * @param name - predstavlja naziv restorana
     * @param address - predstavlja adresu restorana
     * @param meals - predstavlja jela u ponudi
     * @param chefs - predstavlja kuhare u restoranu
     * @param waiters - predstavlja konobare u restoranu
     * @param deliverers - predstavlja dostavljače koji dostavljaju za restoran
     */
    public Restaurant(Long id, String name, Address address, Set<Meal> meals, Set<Chef> chefs, Set<Waiter> waiters, Set<Deliverer> deliverers) {
        super(id);
        this.name = name;
        this.address = address;
        this.meals = meals;
        this.chefs = chefs;
        this.waiters = waiters;
        this.deliverers = deliverers;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Set<Meal> getMeals() {
        return meals;
    }

    public void setMeals(Set<Meal> meals) {
        this.meals = meals;
    }

    public Set<Chef> getChefs() {
        return chefs;
    }

    public void setChefs(Set<Chef> chefs) {
        this.chefs = chefs;
    }

    public Set<Waiter> getWaiters() {
        return waiters;
    }

    public void setWaiters(Set<Waiter> waiters) {
        this.waiters = waiters;
    }

    public Set<Deliverer> getDeliverers() {
        return deliverers;
    }

    public void setDeliverers(Set<Deliverer> deliverers) {
        this.deliverers = deliverers;
    }

    /**
     * Metoda za upis podataka o restoranu
     * @param restaurants - polje restorana u koje se zapisuju podaci
     * @param allMeals - polje jela za odabir koja jela će biti u restoranu
     * @param allChefs - polje kuhara za odabir koji kuhari rade u restoranu
     * @param allWaiters - polje konobara za odabir koji konobari rade u restoranu
     * @param allDeliverers - polje dostavljača za odabir koji dostavljaju iz restorana
     * @param scanner - čitanje podataka s tipkovnice
     */
    public static void inputRestaurant(Restaurant[] restaurants, Set<Meal> allMeals, Set<Chef> allChefs,
                                       Set<Waiter> allWaiters, Set<Deliverer> allDeliverers, Scanner scanner) {
        for (int i = 0; i < restaurants.length; i++) {
            boolean isValid;
            String name;

            do {
                isValid = true;
                System.out.print("Enter the name of the " + (i + 1) + ". restaurant: ");
                name = scanner.nextLine();
                try {
                    DuplicateNameCheck.checkDuplicateRestaurant(name, restaurants, i);
                } catch (DuplicateEntityException e) {
                    isValid = false;
                    log.error(e.getMessage());
                    System.out.println(e.getMessage());
                }
            } while (!isValid);

            System.out.print("Enter address details below \n");
            Address address = Address.inputAddress(Long.valueOf(i + 1), scanner);

            System.out.print("Enter the number of meals " + (i + 1) + ". restaurant has: ");
            int numberOfMeals = InputValidator.validatePositiveInteger(scanner, Messages.INVALID_NUMBER_OF_MEALS_INPUT);
            System.out.println("Available meals: ");
            Set<Meal> meals = DataInputUtils.inputMeals(scanner, allMeals, numberOfMeals, Messages.INVALID_INTEGER_INDEX_MEAL_INPUT);

            System.out.print("Enter the number of chefs " + (i + 1) + ". restaurant has: ");
            int numberOfChefs = InputValidator.validatePositiveInteger(scanner, Messages.INVALID_NUMBER_OF_CHEFS_INPUT);
            System.out.println("Available chefs: ");
            Set<Chef> chefs = DataEmployeeInputUtils.selectChefs(scanner, allChefs, numberOfChefs, Messages.INVALID_CHEF_INDEX_INPUT);

            System.out.print("Enter the number of waiters " + (i + 1) + ". restaurant has: ");
            int numberOfWaiters = InputValidator.validatePositiveInteger(scanner, Messages.INVALID_NUMBER_OF_WAITERS_INPUT);
            System.out.println("Available waiters: ");
            Set<Waiter> waiters = DataEmployeeInputUtils.selectWaiters(scanner, allWaiters, numberOfWaiters, Messages.INVALID_WAITER_INDEX_INPUT);

            System.out.print("Enter the number of deliverers " + (i + 1) + ". restaurant has: ");
            int numberOfDeliverers = InputValidator.validatePositiveInteger(scanner, Messages.INVALID_NUMBRR_OF_DELIVERERS_INPUT);
            System.out.println("Available deliverers: ");
            Set<Deliverer> deliverers = DataEmployeeInputUtils.selectDeliverers(scanner, allDeliverers, numberOfDeliverers, Messages.INVALID_DELIVERER_INDEX_INPUT);

            restaurants[i] = new Restaurant(Long.valueOf(i + 1), name, address, meals, chefs, waiters, deliverers);
        }
    }

}