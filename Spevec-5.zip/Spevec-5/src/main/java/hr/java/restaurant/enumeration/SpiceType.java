package hr.java.restaurant.enumeration;

public enum SpiceType {
    SALT, PEPPER, PAPRIKA, PARSLEY, CINNAMON, GINGER, GARLIC_POWDER, CHILI, OREGANO, ROSEMARY
}
