package hr.java.restaurant.model;

/**
 * Klasa Vegetarian koja predstavlja vegetarijanska jela.
 * Sadrži metode za provjeru ima li jelo mliječne proizvode i jaja.
 */
public sealed interface Vegetarian permits VegetarianMeal{
    boolean containsDairy();
    boolean containsEggs();
}
