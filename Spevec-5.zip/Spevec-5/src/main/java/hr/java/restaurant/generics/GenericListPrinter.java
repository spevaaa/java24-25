package hr.java.restaurant.generics;

import java.util.List;

public class GenericListPrinter {

    public static <T> void printListElements(List<T> list) {
        if (list == null || list.isEmpty()) {
            System.out.println("The list is empty or null.");
            return;
        }

        list.forEach(element -> System.out.println("Element: " + element));
    }
}
