package hr.java.restaurant.model;

/**
 * Zapečaćeno sučelje Vegan koje sadrži dvije metode za dobivanje vrste jela i podatak je li jelo bez glutena.
 */
public sealed interface Vegan permits VeganMeal{
    String getVeganType();
    boolean isGlutenFree();
}
