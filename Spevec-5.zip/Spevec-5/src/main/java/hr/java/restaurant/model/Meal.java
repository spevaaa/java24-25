package hr.java.restaurant.model;

import hr.java.restaurant.enumeration.SpiceType;
import hr.java.restaurant.exception.NegativOrUnrealPrice;
import hr.java.utils.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static hr.java.utils.DataEmployeeInputUtils.inputSpices;

/**
 * Klasa Meal koja predstavlja jela.
 * Sadrži ime, kategoriju, cijenu i broj kalorija jela te sastojke potrebne za to jelo.
 */
public class Meal extends Entity {

    private static Logger log = LoggerFactory.getLogger(Meal.class);

    private String name;
    private Category category;
    private Set<Ingredient> ingredients;
    private BigDecimal price;
    private Integer calories;
    private Set<SpiceType> spices;

    /**
     * Konstruktor za kreiranje objekta tipa Meal
     *
     * @param id          - predstavlja ID jela
     * @param name        - predstavlja ime jela
     * @param category    - predstavlja kategoriju kojoj pripada jelo
     * @param ingredients - predstavlja sastojke koji su potrebni za izradu jela
     * @param price       - predstavlja cijenu jela
     * @param calories    - predstavlja broj kalorija jela
     */
    public Meal(Long id, String name, Category category, Set<Ingredient> ingredients, BigDecimal price, Integer calories, Set<SpiceType> spices) {
        super(id);
        this.name = name;
        this.category = category;
        this.ingredients = ingredients;
        this.price = price;
        this.calories = calories;
        this.spices = spices;
    }

    public Integer getCalories() {
        return calories;
    }

    public void setCalories(Integer calories) {
        this.calories = calories;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Set<Ingredient> getIngredients() {
        return ingredients;
    }

    public void setIngredients(Set<Ingredient> ingredients) {
        this.ingredients = ingredients;
    }

    public Set<SpiceType> getSpices() {
        return spices;
    }

    public void setSpices(Set<SpiceType> spices) {
        this.spices = spices;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    /**
     * Metoda za upis podataka o jelu
     *
     * @param meals       - polje jela u koji se zapisuju podatci o jelu
     * @param categories  - polje kategorija kako bi korisnik odredio u koju kategoriju spada jelo
     * @param ingredients - polje sastojaka kako bi korisnik odredio koji su sastojci potrebni za izradu jela
     * @param scanner     - čitanje podataka s tipkovnice
     */
    public static void inputMeal(Set<Meal> meals, Category[] categories, Set<Ingredient> ingredients, Scanner scanner) {
        for (int i = 0; i < meals.size(); i++) {
            System.out.print("Enter " + (i + 1) + "." + " meal's name: ");
            String name = scanner.nextLine();

            System.out.print("Choose " + (i + 1) + "." + " meal's category (index 1, 2 or 3) : \n");
            for (int j = 0; j < categories.length; j++) {
                System.out.println((j + 1) + "." + categories[j].getName());
            }
            Category category = DataInputUtils.getCategory(categories, scanner, Messages.INVALID_INTEGER_INDEX_CATEGORY_INPUT);

            System.out.print("Enter number of ingredients needed for this meal: ");
            int numberOfIngredients = InputValidator.validatePositiveInteger(scanner, Messages.INVALID_NUMBER_OF_INGREDIENTS);

            System.out.println("Avaliable ingredients: ");
            Set<Ingredient> selectedIngredients = DataInputUtils.inputIngredients(scanner, ingredients, numberOfIngredients, "Invalid index. Please try again.");

            System.out.print("Enter the price of " + (i + 1) + ". meal: ");
            Boolean isValid;
            BigDecimal price;

            do {
                isValid = true;
                price = InputValidator.validatePositiveBigDecimal(scanner, Messages.INVALID_PRICE_NUMBER_INPUT);
                try {
                    PriceCheck.checkPrice(price);
                } catch (NegativOrUnrealPrice e) {
                    isValid = false;
                    log.error(e.getMessage());
                    System.out.println(e.getMessage());
                }
            } while (!isValid);

            System.out.println("Enter calories for this meal: ");
            Integer calories = InputValidator.validatePositiveInteger(scanner, Messages.INVALID_BIGDECIMAL_KCAL_INPUT);

            System.out.println("Select spices for this meal:");
            Set<SpiceType> spices = DataEmployeeInputUtils.inputSpices(scanner, Messages.INVALID_INTEGER_INDEX_CATEGORY_INPUT);

            Meal newMeal = new Meal(Long.valueOf(i + 1), name, category, selectedIngredients, price, calories, spices);
            meals.add(newMeal);

        }
    }

    public static Set<Meal> filterMeals(Set<Meal> meals) {
        Set<Meal> expensiveMeals = meals.stream()
                .filter(meal -> meal.getPrice().compareTo(BigDecimal.TEN) > 0)
                .collect(Collectors.toSet());

        Iterator<Meal> iterator = expensiveMeals.iterator();
        while (iterator.hasNext()) {
            Meal meal = iterator.next();
            if (meal.getSpices() == null || !meal.getSpices().contains(SpiceType.SALT)) {
                iterator.remove();
            }
        }

        return expensiveMeals;
    }

    public static List<Meal> highCalorieMeal(List<Meal> mealList) {
        return mealList.stream()
                .filter(meal -> meal.getCalories() != null && meal.getCalories() > 1000)
                .sorted(Comparator.comparingInt(Meal::getCalories))
                .collect(Collectors.toList());
    }

    public static void printMeals(List<Meal> mealList) {
        mealList.forEach(meal -> System.out.println(
                "Meal: " + meal.getName() +
                        ", Calories: " + (meal.getCalories() != null ? meal.getCalories() : "NULL calories")));
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Meal meal = (Meal) o;
        return Objects.equals(name, meal.name) && Objects.equals(category, meal.category) && Objects.equals(ingredients, meal.ingredients) && Objects.equals(price, meal.price) && Objects.equals(calories, meal.calories);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, category, ingredients, price, calories);
    }
}
