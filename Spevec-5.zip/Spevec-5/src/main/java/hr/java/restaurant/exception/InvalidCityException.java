package hr.java.restaurant.exception;

public class InvalidCityException extends RuntimeException {
    private String cityName;

    public InvalidCityException(String cityName) {
        super("Invalid city: " + cityName);
        this.cityName = cityName;
    }
}