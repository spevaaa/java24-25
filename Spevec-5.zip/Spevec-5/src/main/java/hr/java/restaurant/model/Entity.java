package hr.java.restaurant.model;

/**
 * Apstraktna klasa Entity koju nasljeđuju ostale klase.
 * Sadrži samo ID tipa Long
 */
public abstract class Entity {
    protected Long id;

    /**
     * Konstruktor koji nasljeđuju ostale klase te uz svoj konstruktor, moraju imati i ID
     * @param id - broj koji predstavlja ID entiteta
     */
    public Entity(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
