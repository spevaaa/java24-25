package hr.java.utils;

import hr.java.restaurant.enumeration.SpiceType;
import hr.java.restaurant.model.Chef;
import hr.java.restaurant.model.Deliverer;
import hr.java.restaurant.model.Restaurant;
import hr.java.restaurant.model.Waiter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class DataEmployeeInputUtils {

    private static Logger log = LoggerFactory.getLogger(DataEmployeeInputUtils.class);

    public static Set<Chef> selectChefs(Scanner scanner, Set<Chef> allChefs, int numberOfChefs, String errorMessage) {
        Set<Chef> selectedChefs = new HashSet<>(); // Koristi Set za čuvanje selektovanih kuhara
        List<Chef> chefList = new ArrayList<>(allChefs); // Pretvori Set u listu radi lakšeg pristupa po indeksu

        for (int i = 0; i < chefList.size(); i++) {
            Chef chef = chefList.get(i);
            System.out.println((i + 1) + ". " + chef.getFirstName() + " " + chef.getLastName());
        }

        for (int i = 0; i < numberOfChefs; i++) {
            System.out.print("Choose chef " + (i + 1) + ": ");
            boolean isValid;

            do {
                isValid = true;
                try {
                    int chefIndex = scanner.nextInt();
                    scanner.nextLine(); // Čisti newline znak

                    if (chefIndex < 1 || chefIndex > chefList.size()) {
                        System.out.println(errorMessage);
                        isValid = false;
                    } else {
                        Chef selectedChef = chefList.get(chefIndex - 1);

                        if (!selectedChefs.add(selectedChef)) {
                            System.out.println("This chef is already selected. Please choose a different chef.");
                            isValid = false;
                        }
                    }
                } catch (InputMismatchException e) {
                    log.error(errorMessage);
                    System.out.println(errorMessage);
                    isValid = false;
                    scanner.nextLine();
                }
            } while (!isValid);
        }

        return selectedChefs;
    }


    public static Set<Waiter> selectWaiters(Scanner scanner, Set<Waiter> allWaiters, int numberOfWaiters, String errorMessage) {
        Set<Waiter> selectedWaiters = new HashSet<>();
        List<Waiter> waiterList = new ArrayList<>(allWaiters);

        for (int i = 0; i < waiterList.size(); i++) {
            System.out.println((i + 1) + ". " + waiterList.get(i).getFirstName() + " " + waiterList.get(i).getLastName());
        }

        for (int i = 0; i < numberOfWaiters; i++) {
            System.out.print("Choose waiter " + (i + 1) + ": ");
            int waiterIndex;
            boolean isValid;

            do {
                isValid = true;
                try {
                    waiterIndex = scanner.nextInt();
                    scanner.nextLine();

                    if (waiterIndex < 1 || waiterIndex > waiterList.size()) {
                        System.out.println(errorMessage);
                        isValid = false;
                    } else {
                        selectedWaiters.add(waiterList.get(waiterIndex - 1));
                    }
                } catch (InputMismatchException e) {
                    log.error(errorMessage);
                    System.out.println(errorMessage);
                    isValid = false;
                    scanner.nextLine();
                }
            } while (!isValid);
        }

        return selectedWaiters;
    }


    public static Set<Deliverer> selectDeliverers(Scanner scanner, Set<Deliverer> allDeliverers, int numberOfDeliveries, String errorMessage) {
        Set<Deliverer> selectedDeliverers = new HashSet<>();
        List<Deliverer> delivererList = new ArrayList<>(allDeliverers);

        for (int i = 0; i < delivererList.size(); i++) {
            System.out.println((i + 1) + ". " + delivererList.get(i).getFirstName() + " " + delivererList.get(i).getLastName());
        }

        for (int i = 0; i < numberOfDeliveries; i++) {
            System.out.print("Choose deliverer " + (i + 1) + ": ");
            int delivererIndex;
            boolean isValid;

            do {
                isValid = true;
                try {
                    delivererIndex = scanner.nextInt();
                    scanner.nextLine();
                    if (delivererIndex < 1 || delivererIndex > delivererList.size()) {
                        System.out.println(errorMessage);
                        isValid = false;
                    } else {
                        selectedDeliverers.add(delivererList.get(delivererIndex - 1));
                    }
                } catch (InputMismatchException e) {
                    log.error(errorMessage);
                    System.out.println(errorMessage);
                    isValid = false;
                    scanner.nextLine();
                }
            } while (!isValid);
        }

        return selectedDeliverers;
    }


    public static Deliverer inputDelivererFromRestaurant(Restaurant restaurant, Scanner scanner, String errorMessage) {
        Deliverer selectedDeliverer = null;
        boolean isValid;

        List<Deliverer> delivererList = new ArrayList<>(restaurant.getDeliverers());

        for (int i = 0; i < delivererList.size(); i++) {
            System.out.println((i + 1) + ". " + delivererList.get(i).getFirstName() + " " + delivererList.get(i).getLastName());
        }

        do {
            System.out.print("Choose a deliverer by number: ");
            isValid = true;
            try {
                int delivererIndex = scanner.nextInt();
                scanner.nextLine();

                if (delivererIndex < 1 || delivererIndex > delivererList.size()) {
                    System.out.println(errorMessage);
                    isValid = false;
                } else {
                    selectedDeliverer = delivererList.get(delivererIndex - 1);
                }
            } catch (InputMismatchException e) {
                log.error(errorMessage);
                System.out.println(errorMessage);
                isValid = false;
                scanner.nextLine();
            }
        } while (!isValid);

        return selectedDeliverer;
    }


    public static Set<SpiceType> inputSpices(Scanner scanner, String errorMessage) {
        Set<SpiceType> selectedSpices = new HashSet<>();

        SpiceType[] spices = SpiceType.values();
        System.out.println("Available spices:");
        for (int i = 0; i < spices.length; i++) {
            System.out.println((i + 1) + ". " + spices[i].name());
        }

        System.out.print("Enter the number of spices to select: ");
        int numberOfSpices = InputValidator.validatePositiveInteger(scanner, errorMessage);

        for (int i = 0; i < numberOfSpices; i++) {
            System.out.print("Choose spice " + (i + 1) + ": ");
            int spiceIndex;
            boolean isValid;

            do {
                isValid = true;
                try {
                    spiceIndex = scanner.nextInt();
                    scanner.nextLine();
                    if (spiceIndex < 1 || spiceIndex > spices.length) {
                        System.out.println(errorMessage);
                        isValid = false;
                    } else {
                        selectedSpices.add(spices[spiceIndex - 1]);
                    }
                } catch (InputMismatchException e) {
                    System.out.println(errorMessage);
                    isValid = false;
                    scanner.nextLine();
                }
            } while (!isValid);
        }

        return selectedSpices;
    }

}
