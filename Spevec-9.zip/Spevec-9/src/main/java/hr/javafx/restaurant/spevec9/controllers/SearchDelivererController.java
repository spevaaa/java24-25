package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.restaurant.model.Deliverer;
import hr.javafx.restaurant.spevec9.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.DelivererRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.util.List;
import java.util.stream.Collectors;

public class SearchDelivererController {
    @FXML
    private TextField employeeFirstNameTextField;
    @FXML
    private TextField employeeLastNameTextField;
    @FXML
    private TableView<Deliverer> employeeTableView;
    @FXML
    private TableColumn<Deliverer, String> employeeIdColumn;
    @FXML
    private TableColumn<Deliverer, String> employeeFirstNameColumn;
    @FXML
    private TableColumn<Deliverer, String> employeeLastNameColumn;
    @FXML
    private TableColumn<Deliverer, String> employeeSalaryColumn;
    @FXML
    private TableColumn<Deliverer, String> employeeBonusColumn;

    private AbstractRepository<Deliverer> employeeRepository = new DelivererRepository();

    public void initialize() {
        employeeIdColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getId())));

        employeeFirstNameColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getFirstName()));

        employeeLastNameColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getLastName()));

        employeeSalaryColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getContract().getSalary())));

        employeeBonusColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getBonus().amount())));
    }

    public void filterEmployees() {
        List<Deliverer> delivererList = employeeRepository.findAll();

        String employeeFirstName = employeeFirstNameTextField.getText();
        if(!employeeFirstName.isEmpty()) {
            delivererList = delivererList.stream()
                    .filter(employee -> employee.getFirstName().toLowerCase().contains(employeeFirstName.toLowerCase()))
                    .collect(Collectors.toList());
        }

        String employeeLastName = employeeLastNameTextField.getText();
        if(!employeeLastName.isEmpty()) {
            delivererList = delivererList.stream()
                    .filter(employee -> employee.getLastName().toLowerCase().contains(employeeLastName.toLowerCase()))
                    .collect(Collectors.toList());
        }

        ObservableList<Deliverer> delivererObservableList = FXCollections.observableList(delivererList);
        employeeTableView.setItems(delivererObservableList);
    }
}
