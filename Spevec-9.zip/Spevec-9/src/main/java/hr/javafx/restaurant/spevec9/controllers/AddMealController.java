package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.main.Main;
import hr.javafx.restaurant.spevec9.restaurant.model.Category;
import hr.javafx.restaurant.spevec9.restaurant.model.Ingredient;
import hr.javafx.restaurant.spevec9.restaurant.model.Meal;
import hr.javafx.restaurant.spevec9.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.CategoriesRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.IngredientRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.MealRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class AddMealController {
    @FXML
    private TextField newMealNameTextField;
    @FXML
    private ComboBox<String> mealCategoryComboBox;
    @FXML
    ListView<String> addIngredientsListView;
    @FXML
    private TextField newMealPriceTextField;

    private AbstractRepository<Ingredient> ingredientRepository = new IngredientRepository();
    private ObservableList<String> ingredientObservableList;

    private AbstractRepository<Meal> mealRepository = new MealRepository<>();

    private AbstractRepository<Category> categoryRepository = new CategoriesRepository<>();
    private List<Category> categoryList = categoryRepository.findAll();
    private ObservableList<String> categoryObservableList = FXCollections.observableArrayList(categoryList.stream().map(Category::getName).collect(Collectors.toList()));

    public void initialize() {
        List<Ingredient> ingredientList = ingredientRepository.findAll();
        ingredientObservableList = FXCollections.observableArrayList(ingredientList.stream().map(Ingredient::getName).collect(Collectors.toSet()));
        addIngredientsListView.setItems(ingredientObservableList);
        addIngredientsListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        mealCategoryComboBox.setItems(categoryObservableList);
    }

    public void addMeal(){
        String mealName = newMealNameTextField.getText();
        String categoryName = mealCategoryComboBox.getValue();
        Category category = categoryList.stream()
                .filter(c -> c.getName().equals(categoryName))
                .findFirst()
                .orElse(null);

        Set<Ingredient> ingredientSet = addIngredientsListView.getSelectionModel()
                .getSelectedItems()
                .stream()
                .map(selectedName -> ingredientRepository.findAll().stream()
                        .filter(ingredient -> ingredient.getName().equals(selectedName))
                        .findFirst()
                        .orElse(null))
                .filter(ingredient -> ingredient != null)
                .collect(Collectors.toSet());

        BigDecimal price = new BigDecimal(newMealPriceTextField.getText());

        Meal meal = new Meal(mealName, category, ingredientSet, price);
        mealRepository.save(meal);

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec9/showMeals.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
