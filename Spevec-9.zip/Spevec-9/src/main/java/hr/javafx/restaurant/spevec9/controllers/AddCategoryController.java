package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.main.Main;
import hr.javafx.restaurant.spevec9.restaurant.model.Category;
import hr.javafx.restaurant.spevec9.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.CategoriesRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public class AddCategoryController {
    @FXML
    private TextField newCategoryNameTextField;
    @FXML
    private TextField newCategoryDescriptionTextField;

    private AbstractRepository<Category> categoryRepository = new CategoriesRepository();
    private List<Category> categories = categoryRepository.findAll();
    private ObservableList<String> categoryObservableList = FXCollections.observableArrayList(categories.stream().map(Category::getName).collect(Collectors.toList()));

    public void initialize() {}


    public void addCategory(){
        String name = newCategoryNameTextField.getText();
        String description = newCategoryDescriptionTextField.getText();

        Category newCategory = new Category(name, description);
        categoryRepository.save(newCategory);

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec9/showCategories.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
