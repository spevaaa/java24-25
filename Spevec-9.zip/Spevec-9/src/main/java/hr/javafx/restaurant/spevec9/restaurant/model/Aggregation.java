package hr.javafx.restaurant.spevec9.restaurant.model;

import java.time.LocalDate;

public class Aggregation {

    private Long id;
    private Meal meal;
    private Long ingredientNumber;
    private LocalDate startDate;
    private LocalDate endDate;

    public Aggregation(Long id, Meal meal, Long ingredientNumber, LocalDate startDate, LocalDate endDate) {
        this.id = id;
        this.meal = meal;
        this.ingredientNumber = ingredientNumber;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Meal getMeal() {
        return meal;
    }

    public void setMeal(Meal meal) {
        this.meal = meal;
    }

    public Long getIngredientNumber() {
        return ingredientNumber;
    }

    public void setIngredientNumber(Long ingredientNumber) {
        this.ingredientNumber = ingredientNumber;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }
}
