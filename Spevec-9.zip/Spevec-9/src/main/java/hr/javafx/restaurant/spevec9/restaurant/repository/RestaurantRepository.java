package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.exception.EmptyRepositoryResultException;
import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RestaurantRepository <T extends Restaurant> extends AbstractRepository<T> {
    private static final String RESTAURANTS_FILE_PATH = "dat/restaurants.txt";
    private static final Integer NUMBER_OF_ROWS_PER_RESTAURANT = 7;

    @Override
    public List<T> findAll() {
        List<T> restaurants = new ArrayList<>();
        AddressRepository<Address> addressRepository = new AddressRepository<>();

        try (Connection connection = Database.connectToDatabase()) {
            Statement stmt = connection.createStatement();
            ResultSet resultSet = stmt.executeQuery("SELECT * FROM RESTAURANT;");

            while (resultSet.next()) {

                Long restaurantId = resultSet.getLong("id");
                String name = resultSet.getString("name");
                Long addressId = resultSet.getLong("address_id");

                Address restaurantAddress = addressRepository.findById(addressId);

                Set<Meal> meals = RestaurantMealsRepository.getMealsForRestaurant(restaurantId);
                Set<Chef> chefs = RestaurantChefsRepository.getChefsForRestaurant(restaurantId);
                Set<Waiter> waiters = RestaurantWaitersRepository.getWaitersForRestaurant(restaurantId);
                Set<Deliverer> deliverers = RestaurantDeliverersRepository.getDeliverersForRestaurant(restaurantId);


                Restaurant restaurant = new Restaurant(restaurantId, name, restaurantAddress, meals, chefs, waiters, deliverers);
                restaurants.add((T) restaurant);
            }
            return restaurants;
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public T findById(Long id) {
        AddressRepository<Address> addressRepository = new AddressRepository<>();
        try (Connection connection = Database.connectToDatabase()) {

            PreparedStatement stmt = connection.prepareStatement(
                    "SELECT * FROM RESTAURANT WHERE ID = ?;");
            stmt.setLong(1, id);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
               Long restaurantId = resultSet.getLong("id");
               String name = resultSet.getString("name");
               Long addressId = resultSet.getLong("address_id");

                Address restaurantAddress = addressRepository.findById(addressId);

                Set<Meal> meals = RestaurantMealsRepository.getMealsForRestaurant(id);
                Set<Chef> chefs = RestaurantChefsRepository.getChefsForRestaurant(id);
                Set<Waiter> waiters = RestaurantWaitersRepository.getWaitersForRestaurant(id);
                Set<Deliverer> deliverers = RestaurantDeliverersRepository.getDeliverersForRestaurant(id);

                return (T) new Restaurant(restaurantId, name, restaurantAddress, meals, chefs, waiters, deliverers);

            } else {
                throw new EmptyRepositoryResultException("Restaurant with id " + id + " not found");
            }

        } catch (SQLException | IOException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(List<T> entities) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO RESTAURANT (NAME, ADDRESS_ID) VALUES (?, ?);", Statement.RETURN_GENERATED_KEYS);

            for (Restaurant restaurant : entities) {
                stmt.setString(1, restaurant.getName());
                stmt.setLong(2, restaurant.getAddress().getId());
                stmt.executeUpdate();

                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    restaurant.setId(generatedKeys.getLong(1));
                }

                RestaurantMealsRepository.saveMealsForRestaurant(restaurant);
                RestaurantChefsRepository.saveChefsForRestaurant(restaurant);
                RestaurantWaitersRepository.saveWaitersForRestaurant(restaurant);
                RestaurantDeliverersRepository.saveDeliverersForRestaurant(restaurant);
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(T entity) {

        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO RESTAURANT (NAME, ADDRESS_ID) VALUES (?, ?);", Statement.RETURN_GENERATED_KEYS);

            stmt.setString(1, entity.getName());
            stmt.setLong(2, entity.getAddress().getId());
            stmt.executeUpdate();

            ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                entity.setId(generatedKeys.getLong(1));
            }

            RestaurantMealsRepository.saveMealsForRestaurant(entity);
            RestaurantChefsRepository.saveChefsForRestaurant(entity);
            RestaurantWaitersRepository.saveWaitersForRestaurant(entity);
            RestaurantDeliverersRepository.saveDeliverersForRestaurant(entity);

        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }

    }

    private Long generateNewId() {
        return findAll().stream().map(i -> i.getId())
                .max((i1, i2) -> i1.compareTo(i2)).orElse(0l) + 1;
    }
}
