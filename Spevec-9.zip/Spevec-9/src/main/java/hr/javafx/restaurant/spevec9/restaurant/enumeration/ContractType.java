package hr.javafx.restaurant.spevec9.restaurant.enumeration;

public enum ContractType {
    FULL_TIME("FULL_TIME"),
    PART_TIME("PART_TIME");

    private String contractType;

    ContractType(String contractType) {
        this.contractType = contractType;
    }

    public String getContractType() {
        return contractType;
    }

    public void setContractType(String contractType) {
        this.contractType = contractType;
    }
}
