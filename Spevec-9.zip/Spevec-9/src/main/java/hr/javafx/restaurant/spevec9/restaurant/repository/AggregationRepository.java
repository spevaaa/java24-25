package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AggregationRepository {

    private static final String SELECT_BY_DATE_RANGE = """
        SELECT a.ID, a.MEAL_ID, a.INGREDIENT_NUMBER, a.START_DATE, a.END_DATE, 
               m.NAME AS MEAL_NAME, m.CATEGORY, m.PRICE
        FROM AGGREGATION a 
        INNER JOIN MEAL m ON a.MEAL_ID = m.ID
        WHERE a.START_DATE >= ? AND a.END_DATE <= ?
        """;

    private static final String INSERT_AGGREGATION = """
        INSERT INTO AGGREGATION (MEAL_ID, INGREDIENT_NUMBER, START_DATE, END_DATE)
        VALUES (?, ?, ?, ?)
    """;

    public void saveAggregation(Aggregation aggregation) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement statement = connection.prepareStatement(INSERT_AGGREGATION);

            statement.setLong(1, aggregation.getMeal().getId());
            statement.setLong(2, aggregation.getIngredientNumber());
            statement.setDate(3, Date.valueOf(aggregation.getStartDate()));
            statement.setDate(4, Date.valueOf(aggregation.getEndDate()));

            statement.executeUpdate();
        } catch (IOException | SQLException e) {
            e.printStackTrace();
            throw new RepositoryAccessException(e);
        }
    }

    public List<Aggregation> findByDateRange(LocalDate startDate, LocalDate endDate) {
        List<Aggregation> aggregations = new ArrayList<>();

        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement statement = connection.prepareStatement(SELECT_BY_DATE_RANGE);
            statement.setDate(1, Date.valueOf(startDate));
            statement.setDate(2, Date.valueOf(endDate));

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Long id = resultSet.getLong("ID");
                Long mealId = resultSet.getLong("MEAL_ID");
                String mealName = resultSet.getString("MEAL_NAME");
                String categoryName = resultSet.getString("CATEGORY");
                BigDecimal price = resultSet.getBigDecimal("PRICE");
                Long ingredientNumber = resultSet.getLong("INGREDIENT_NUMBER");
                LocalDate start = resultSet.getDate("START_DATE").toLocalDate();
                LocalDate end = resultSet.getDate("END_DATE").toLocalDate();

                Category category = new Category(categoryName, "Description for this category");

                Meal meal = getMealWithIngredients(mealId, mealName, category, price);

                Aggregation aggregation = new Aggregation(id, meal, ingredientNumber, start, end);
                aggregations.add(aggregation);
            }

        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException("Error fetching aggregations by date range", e);
        }

        return aggregations;
    }

    private Meal getMealWithIngredients(Long mealId, String mealName, Category category, BigDecimal price) {
        Set<Ingredient> ingredients = getIngredientsForMeal(mealId);
        return new Meal(mealId, mealName, category, ingredients, price);
    }

    private Set<Ingredient> getIngredientsForMeal(Long mealId) {
        CategoriesRepository<Category> categoryRepository = new CategoriesRepository<>();
        Set<Ingredient> ingredients = new HashSet<>();

        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("""
                SELECT i.ID, i.NAME, i.CATEGORY_ID, i.KCAL, i.PREPARATION_METHOD
                FROM MEAL_INGREDIENT mi
                JOIN INGREDIENT i ON mi.INGREDIENT_ID = i.ID
                WHERE mi.MEAL_ID = ?;
            """);

            stmt.setLong(1, mealId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Long resultId = resultSet.getLong("ID");
                String name = resultSet.getString("NAME");
                BigDecimal kcal = resultSet.getBigDecimal("KCAL");
                String preparationMethod = resultSet.getString("PREPARATION_METHOD");
                Long categoryId = resultSet.getLong("CATEGORY_ID");
                Category category = categoryRepository.findById(categoryId);

                Ingredient ingredient = new Ingredient(resultId, name, category, kcal, preparationMethod);
                ingredients.add(ingredient);
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException("Error fetching ingredients for meal ID " + mealId, e);
        }

        return ingredients;
    }


    public List<Aggregation> findAllAggregations() {
        List<Aggregation> aggregations = new ArrayList<>();
        CategoriesRepository<Category> categoryRepository = new CategoriesRepository<>();


        String query = "SELECT a.ID, a.MEAL_ID, a.INGREDIENT_NUMBER, a.START_DATE, a.END_DATE, " +
                "m.NAME AS MEAL_NAME, m.CATEGORY, m.PRICE " +
                "FROM AGGREGATION a " +
                "INNER JOIN MEAL m ON a.MEAL_ID = m.ID";

        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Long id = resultSet.getLong("ID");
                Long mealId = resultSet.getLong("MEAL_ID");
                String mealName = resultSet.getString("MEAL_NAME");
                String category = resultSet.getString("CATEGORY");
                BigDecimal price = resultSet.getBigDecimal("PRICE");
                Long ingredientNumber = resultSet.getLong("INGREDIENT_NUMBER");
                LocalDate startDate = resultSet.getDate("START_DATE").toLocalDate();
                LocalDate endDate = resultSet.getDate("END_DATE").toLocalDate();

                Category mealCategory = categoryRepository.findById(id);
                Meal meal = new Meal(mealId, mealName, mealCategory, new HashSet<>(), price);

                Aggregation aggregation = new Aggregation(id, meal, ingredientNumber, startDate, endDate);
                aggregations.add(aggregation);
            }

        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }

        return aggregations;
    }
}