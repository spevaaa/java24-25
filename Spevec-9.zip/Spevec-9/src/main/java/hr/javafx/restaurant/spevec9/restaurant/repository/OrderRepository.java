package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class OrderRepository<T extends Order> extends AbstractRepository<T> {
    private static final String ORDERS_FILE_PATH = "dat/orders.txt";

    @Override
    public List<T> findAll() {
        List<T> orders = new ArrayList<>();
        RestaurantRepository<Restaurant> restaurantRepository = new RestaurantRepository<>();
        DelivererRepository<Deliverer> delivererRepository = new DelivererRepository<>();

        try (Connection connection = Database.connectToDatabase()) {
            Statement stmt = connection.createStatement();
            ResultSet resultSet = stmt.executeQuery("SELECT * FROM RESTAURANT_ORDER;");

            while (resultSet.next()) {

                Long id = resultSet.getLong("ID");
                Restaurant restaurant = restaurantRepository.findById(resultSet.getLong("RESTAURANT_ID"));
                List<Meal> meals = OrderMealsRepository.getMealsForOrder(id);
                Deliverer deliverer = delivererRepository.findById(resultSet.getLong("DELIVERER_ID"));
                LocalDateTime deliveryDateAndTime = resultSet.getTimestamp("DATE_AND_TIME").toLocalDateTime();

                Order order = new Order(id, restaurant, meals, deliverer, deliveryDateAndTime);
                orders.add((T) order);
            }

            return orders;
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }

    }

    @Override
    public T findById(Long id) {
        RestaurantRepository<Restaurant> restaurantRepository = new RestaurantRepository<>();
        DelivererRepository<Deliverer> delivererRepository = new DelivererRepository<>();

        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM RESTAURANT_ORDER WHERE ID = ?;");
            stmt.setLong(1, id);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                Long orderId = resultSet.getLong("ID");
                Restaurant restaurant = restaurantRepository.findById(resultSet.getLong("RESTAURANT_ID"));
                List<Meal> meals = OrderMealsRepository.getMealsForOrder(id);
                Deliverer deliverer = delivererRepository.findById(resultSet.getLong("DELIVERER_ID"));
                LocalDateTime deliveryDateAndTime = resultSet.getTimestamp("DATE_AND_TIME").toLocalDateTime();

                return (T) new Order(orderId, restaurant, meals, deliverer, deliveryDateAndTime);
            } else {
                throw new RepositoryAccessException("Order with id " + id + " not found");
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(List<T> entities) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("""
                    INSERT INTO RESTAURANT_ORDER (RESTAURANT_ID, DELIVERER_ID, DATE_AND_TIME) VALUES (?, ?, ?);
                    """, Statement.RETURN_GENERATED_KEYS);

            for (Order order : entities) {
                stmt.setLong(1, order.getRestaurant().getId());
                stmt.setLong(2, order.getDeliverer().getId());
                stmt.setTimestamp(3, Timestamp.valueOf(order.getDeliveryDateAndTime()));
                stmt.executeUpdate();

                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    order.setId(generatedKeys.getLong(1));
                }

                OrderMealsRepository.saveMealsForOrder(order);
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(T entity) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("""
                        INSERT INTO RESTAURANT_ORDER (RESTAURANT_ID, DELIVERER_ID, DATE_AND_TIME) VALUES (?, ?, ?);
                    """, Statement.RETURN_GENERATED_KEYS);

            stmt.setLong(1, entity.getRestaurant().getId());
            stmt.setLong(2, entity.getDeliverer().getId());
            stmt.setTimestamp(3, Timestamp.valueOf(entity.getDeliveryDateAndTime()));
            stmt.executeUpdate();

            ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                entity.setId(generatedKeys.getLong(1));
            }

            OrderMealsRepository.saveMealsForOrder(entity);
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    private Long generateNewId() {
        return findAll().stream().map(i -> i.getId())
                .max((i1, i2) -> i1.compareTo(i2)).orElse(0l) + 1;
    }
}
