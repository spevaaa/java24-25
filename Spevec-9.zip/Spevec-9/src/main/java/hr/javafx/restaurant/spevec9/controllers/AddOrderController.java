package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.main.Main;
import hr.javafx.restaurant.spevec9.restaurant.model.*;
import hr.javafx.restaurant.spevec9.restaurant.repository.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class AddOrderController {
    @FXML
    private ComboBox<String> orderRestaurantComboBox;
    @FXML
    private ListView<String> mealsListView;
    @FXML
    private ComboBox<String> orderDelivererComboBox;
    @FXML
    private DatePicker orderDateDatePicker;
    @FXML
    private ComboBox<Integer> orderHoursComboBox;
    @FXML
    private ComboBox<Integer> orderMinutesComboBox;

    public AbstractRepository<Order> orderRepository = new OrderRepository();

    public AbstractRepository<Restaurant> restaurantRepository = new RestaurantRepository<>();
    public List<Restaurant> restaurantList = restaurantRepository.findAll();
    public ObservableList<String> restaurantObservableList = FXCollections.observableArrayList(restaurantList.stream().map(Restaurant::getName).collect(Collectors.toList()));

    public AbstractRepository<Deliverer> delivererRepository = new DelivererRepository();
    public List<Deliverer> delivererList = delivererRepository.findAll();
    public ObservableList<String> delivererObservableList = FXCollections.observableArrayList(delivererList.stream().map(Deliverer::getFirstName).collect(Collectors.toList()));

    private AbstractRepository<Meal> mealRepository = new MealRepository<>();
    private ObservableList<String> mealObservableList;

    public void initialize() {
        orderHoursComboBox.setItems(FXCollections.observableArrayList(
                java.util.stream.IntStream.range(0, 24).boxed().toList()));
        orderMinutesComboBox.setItems(FXCollections.observableArrayList(0, 15, 30, 45));

        orderRestaurantComboBox.setItems(restaurantObservableList);
        orderDelivererComboBox.setItems(delivererObservableList);

        List<Meal> mealList = mealRepository.findAll();
        mealObservableList = FXCollections.observableArrayList(mealList.stream().map(Meal::getName).collect(Collectors.toSet()));
        mealsListView.setItems(mealObservableList);

        mealsListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

    }

    public void addOrder(){

        String restaurantName = orderRestaurantComboBox.getValue();
        Restaurant newRestaurant = restaurantList.stream().filter(restaurant -> restaurant.getName().equals(restaurantName)).findFirst().orElse(null);
        String delivererName = orderDelivererComboBox.getValue();
        Deliverer newDeliverer = delivererList.stream().filter(deliverer -> deliverer.getFirstName().equals(delivererName)).findFirst().orElse(null);

        List<Meal> mealSet = mealsListView.getSelectionModel()
                .getSelectedItems()
                .stream()
                .map(selectedName -> mealRepository.findAll().stream()
                        .filter(meal -> meal.getName().equals(selectedName))
                        .findFirst()
                        .orElse(null))
                .filter(meal -> meal != null)
                .collect(Collectors.toList());


        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy. HH:mm");

        LocalDate date = orderDateDatePicker.getValue();
        Integer hour = orderHoursComboBox.getValue();
        Integer minute = orderMinutesComboBox.getValue();

        LocalDateTime localDateTime = LocalDateTime.of(date, LocalTime.of(hour, minute));

        String formattedDateTime = localDateTime.format(dateTimeFormatter);
        LocalDateTime parsedDateTime = LocalDateTime.parse(formattedDateTime, dateTimeFormatter);

        Order order = new Order(newRestaurant, mealSet, newDeliverer, parsedDateTime);

        orderRepository.save(order);

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec9/showOrders.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}
