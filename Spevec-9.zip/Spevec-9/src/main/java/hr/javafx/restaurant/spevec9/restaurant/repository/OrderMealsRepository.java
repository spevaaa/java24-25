package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class OrderMealsRepository {

    public static void saveMealsForOrder(Order order) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("""
                INSERT INTO RESTAURANT_ORDER_MEAL (RESTAURANT_ORDER_ID, MEAL_ID) VALUES (?, ?);
                """);

            for (Meal meal : order.getMeals()) {
                stmt.setLong(1, order.getId());
                stmt.setLong(2, meal.getId());
                stmt.executeUpdate();
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    public static List<Meal> getMealsForOrder(Long orderId) {
        List<Meal> meals = new ArrayList<>();
        CategoriesRepository<Category> categoryRepository = new CategoriesRepository<>();

        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("""
                SELECT m.*
                FROM RESTAURANT_ORDER_MEAL rom
                JOIN MEAL m ON rom.MEAL_ID = m.ID
                WHERE rom.RESTAURANT_ORDER_ID = ?;
                """);

            stmt.setLong(1, orderId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {

                Long id = resultSet.getLong("ID");
                String name = resultSet.getString("NAME");
                Category category = categoryRepository.findById(resultSet.getLong("CATEGORY_ID"));
                BigDecimal price = resultSet.getBigDecimal("PRICE");
                Set<Ingredient> ingredients = MealIngredientsRepository.getIngredientsForMeal(id);

                Meal meal = new Meal(id, name, category, ingredients, price);
                meals.add(meal);
            }

            return meals;
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }



}
