package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.main.Main;
import hr.javafx.restaurant.spevec9.restaurant.model.Contract;
import hr.javafx.restaurant.spevec9.restaurant.model.DataHolder;
import hr.javafx.restaurant.spevec9.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.ContractRepository;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;

import java.io.IOException;
import java.math.BigDecimal;

public class AddContractController3 {

    @FXML
    public Label nameLabel;
    @FXML
    public Label salaryLabel;
    @FXML
    public Label contractTypeLabel;
    @FXML
    public Label startDateLabel;
    @FXML
    public Label endDateLabel;
    @FXML
    public ListView<String> fileListView;

    public void initialize() {
        nameLabel.setText(DataHolder.contractName);
        salaryLabel.setText(String.valueOf(DataHolder.contractSalary));
        contractTypeLabel.setText(String.valueOf(DataHolder.contractType));
        startDateLabel.setText(String.valueOf(DataHolder.contractStartDate));
        endDateLabel.setText(String.valueOf(DataHolder.contractEndDate));
        fileListView.getItems().addAll(DataHolder.files);
    }

    public void backStep(){

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec9/addContract2.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveContract() {
        ContractRepository<Contract> contractRepository = new ContractRepository<>();
        Contract newContract = new Contract(DataHolder.contractName, DataHolder.contractSalary, DataHolder.contractStartDate, DataHolder.contractEndDate, DataHolder.contractType);
        contractRepository.save(newContract);

        DataHolder.contractName = "";
        DataHolder.contractSalary = BigDecimal.ZERO;
        DataHolder.contractType = null;
        DataHolder.contractStartDate = null;
        DataHolder.contractEndDate = null;

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec9/showContracts.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
