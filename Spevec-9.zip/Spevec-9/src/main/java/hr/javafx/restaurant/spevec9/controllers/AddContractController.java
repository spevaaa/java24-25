package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.main.Main;
import hr.javafx.restaurant.spevec9.restaurant.enumeration.ContractType;
import hr.javafx.restaurant.spevec9.restaurant.model.Contract;
import hr.javafx.restaurant.spevec9.restaurant.model.DataHolder;
import hr.javafx.restaurant.spevec9.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.ContractRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class AddContractController {
    @FXML
    public TextField newContractNameTextField;
    @FXML
    public TextField newContractSalaryTextField;
    @FXML
    public ComboBox<ContractType> contractTypeComboBox;
    @FXML
    public DatePicker newContractStartDate;
    @FXML
    public DatePicker newContractEndDate;

    private AbstractRepository<Contract> contractRepository = new ContractRepository<>();

    public void initialize() {
        contractTypeComboBox.getItems().addAll(ContractType.values());
        if (!DataHolder.contractName.equals("")) {
            newContractNameTextField.setText(DataHolder.contractName);
        }
        if (DataHolder.contractSalary.compareTo(BigDecimal.ZERO) != 0) {
            newContractSalaryTextField.setText(DataHolder.contractSalary.toString());
        }
        if (DataHolder.contractType != null) {
            contractTypeComboBox.setValue(DataHolder.contractType);
        }
        if (DataHolder.contractStartDate != null) {
            newContractStartDate.setValue(DataHolder.contractStartDate);
        }
        if (DataHolder.contractEndDate != null) {
            newContractEndDate.setValue(DataHolder.contractEndDate);
        }
    }

    public void addContract() {
        String salary = newContractSalaryTextField.getText();
        BigDecimal newSalary = BigDecimal.valueOf(Double.parseDouble(salary));
        ContractType newContractType = contractTypeComboBox.getValue();
        LocalDate contractStartDate = newContractStartDate.getValue();
        LocalDate contractEndDate = newContractEndDate.getValue();

        Contract newContract = new Contract(newSalary, contractStartDate, contractEndDate, newContractType);
        contractRepository.save(newContract);

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec9/showContracts.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void nextStep(){
        DataHolder.contractName = newContractNameTextField.getText();
        DataHolder.contractSalary = BigDecimal.valueOf(Double.parseDouble(newContractSalaryTextField.getText()));
        DataHolder.contractType = contractTypeComboBox.getValue();
        DataHolder.contractStartDate = newContractStartDate.getValue();
        DataHolder.contractEndDate = newContractEndDate.getValue();

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec9/addContract2.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
