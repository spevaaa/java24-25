package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.exception.EmptyRepositoryResultException;
import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DelivererRepository<T extends Deliverer> extends AbstractRepository<T> {
    private static final String DELIVERERS_FILE_PATH = "dat/deliverers.txt";
    private static final Integer NUMBER_OF_ROWS_PER_DELIVERER = 5;

    @Override
    public List<T> findAll() {
        List<T> deliverers = new ArrayList<>();
        ContractRepository<Contract> contractRepository = new ContractRepository<>();

        try (Connection connection = Database.connectToDatabase()) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM DELIVERER");

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                BigDecimal bonus = resultSet.getBigDecimal("bonus");
                Bonus newBonus = new Bonus(bonus);
                Long contractId = resultSet.getLong("contract_id");

                Contract contract = contractRepository.findById(contractId);
                Deliverer deliverer = new Deliverer(id, firstName, lastName, contract, newBonus);
                deliverers.add((T) deliverer);
            }

            return deliverers;
        } catch (SQLException | IOException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public T findById(Long id) {
        ContractRepository<Contract> contractRepository = new ContractRepository<>();
        try (Connection connection = Database.connectToDatabase()) {

            PreparedStatement stmt = connection.prepareStatement(
                    "SELECT * FROM DELIVERER WHERE ID = ?;");
            stmt.setLong(1, id);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                Long delivererId = resultSet.getLong("id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                BigDecimal bonus = resultSet.getBigDecimal("bonus");
                Bonus newBonus = new Bonus(bonus);
                Long contractId = resultSet.getLong("contract_id");

                Contract contract = contractRepository.findById(contractId);
                Deliverer deliverer = new Deliverer(delivererId, firstName, lastName, contract, newBonus);
                return (T) deliverer;

            } else {
                throw new EmptyRepositoryResultException("Deliverer with id " + id + " not found");
            }

        } catch (SQLException | IOException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(List<T> entities) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement(
                    "INSERT INTO DELIVERER (FIRST_NAME, LAST_NAME, CONTRACT_ID, BONUS) VALUES (?, ?, ?, ?);");

            for (Deliverer deliverer : entities) {
                stmt.setString(1, deliverer.getFirstName());
                stmt.setString(2, deliverer.getLastName());
                stmt.setLong(3, deliverer.getContract().getId());
                stmt.setBigDecimal(4, deliverer.getBonus().amount());
                stmt.executeUpdate();
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(T entity) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement(
                    "INSERT INTO DELIVERER (FIRST_NAME, LAST_NAME, CONTRACT_ID, BONUS) VALUES (?, ?, ?, ?);");
            stmt.setString(1, entity.getFirstName());
            stmt.setString(2, entity.getLastName());
            stmt.setLong(3, entity.getContract().getId());
            stmt.setBigDecimal(4, entity.getBonus().amount());
            stmt.executeUpdate();
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    private Long generateNewId() {
        return findAll().stream().map(i -> i.getId())
                .max((i1, i2) -> i1.compareTo(i2)).orElse(0l) + 1;
    }
}

