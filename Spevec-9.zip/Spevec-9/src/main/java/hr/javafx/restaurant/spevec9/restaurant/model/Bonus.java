package hr.javafx.restaurant.spevec9.restaurant.model;

import java.math.BigDecimal;

public record Bonus(BigDecimal amount) {
}
