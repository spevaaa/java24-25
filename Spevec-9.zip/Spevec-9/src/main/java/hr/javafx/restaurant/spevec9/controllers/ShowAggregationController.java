package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.restaurant.model.Aggregation;
import hr.javafx.restaurant.spevec9.restaurant.model.Meal;
import hr.javafx.restaurant.spevec9.restaurant.model.Order;
import hr.javafx.restaurant.spevec9.restaurant.repository.AggregationRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.MealRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.OrderRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ShowAggregationController {

    @FXML
    private DatePicker aggFromDatePicker;
    @FXML
    private DatePicker aggToDatePicker;
    @FXML
    private TableView<Aggregation> tableView;
    @FXML
    private TableColumn<Aggregation, String> idColumn;
    @FXML
    private TableColumn<Aggregation, String> mealColumn;
    @FXML
    private TableColumn<Aggregation, String> ingredientsColumn;
    @FXML
    private TableColumn<Aggregation, String> startDateColumn;
    @FXML
    private TableColumn<Aggregation, String> endDateColumn;


    public void initialize() {
        idColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getId().toString()));
        mealColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getMeal().getName()));
        ingredientsColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getIngredientNumber().toString()));
        startDateColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getStartDate().toString()));
        endDateColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getEndDate().toString()));
    }

    public void confirmAggregation() {
        OrderRepository<Order> orderRepository = new OrderRepository<>();
        AggregationRepository aggregationRepository = new AggregationRepository();

        List<Order> orders = orderRepository.findAll();
        LocalDate dateFromAggregation = aggFromDatePicker.getValue();
        LocalDate dateToAggregation = aggToDatePicker.getValue();

        List<Order> filteredOrders = orders.stream()
                .filter(order -> {
                    LocalDate orderDate = order.getDeliveryDateAndTime().toLocalDate();
                    return (orderDate.isEqual(dateFromAggregation) || orderDate.isAfter(dateFromAggregation)) &&
                            (orderDate.isEqual(dateToAggregation) || orderDate.isBefore(dateToAggregation));
                })
                .collect(Collectors.toList());

        for (Order order : filteredOrders) {
            for (Meal meal : order.getMeals()) {
                Aggregation aggregation = new Aggregation(
                        order.getId(),
                        meal,
                        (long) meal.getIngredients().size(),
                        dateFromAggregation,
                        dateToAggregation
                );
                aggregationRepository.saveAggregation(aggregation);
            }
        }

        List<Aggregation> aggregations = aggregationRepository.findAllAggregations();

        tableView.getItems().clear();
        tableView.getItems().addAll(aggregations);
    }
}
