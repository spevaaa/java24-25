package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.restaurant.enumeration.ContractType;
import hr.javafx.restaurant.spevec9.restaurant.model.Contract;
import hr.javafx.restaurant.spevec9.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.ContractRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

public class SearchContractController {
    @FXML
    private TextField salaryTextField;
    @FXML
    private TableView<Contract> contractTableView;
    @FXML
    private TableColumn<Contract, String> contractIdColumn;
    @FXML
    private TableColumn<Contract, String> contractSalaryColumn;
    @FXML
    private TableColumn<Contract, String> contractStartDateColumn;
    @FXML
    private TableColumn<Contract, String> contractEndDateColumn;
    @FXML
    private TableColumn<Contract, String> contractTypeColumn;
    @FXML
    private TextField contractTypeTextField;
    @FXML
    private DatePicker startDateDatePicker;
    @FXML
    private DatePicker endDateDatePicker;


    @FXML
    private TextField addSalaryTextField;
    @FXML
    private ComboBox<ContractType> addContractTypeComboBox;
    @FXML
    private DatePicker addStartDateDatePicker;
    @FXML
    private DatePicker addEndDateDatePicker;

    private AbstractRepository<Contract> contractRepository = new ContractRepository();

    public void initialize() {
        contractIdColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getId())));

        contractSalaryColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getSalary())));

        contractStartDateColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getStartDate())));

        contractEndDateColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getStartDate())));

        contractTypeColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getContractType().getContractType()));

    }

    public void filterContracts() {
        List<Contract> contractList = contractRepository.findAll();

        if (!salaryTextField.getText().isEmpty()) {
            BigDecimal salary = new BigDecimal(salaryTextField.getText());
            contractList = contractList.stream()
                    .filter(contract -> contract.getSalary().compareTo(salary) <= 0)
                    .collect(Collectors.toList());
        }

        if (startDateDatePicker.getValue() != null) {
            contractList = contractList.stream()
                    .filter(contract -> contract.getStartDate() != null && !contract.getStartDate().isBefore(startDateDatePicker.getValue()))
                    .collect(Collectors.toList());
        }

        if (endDateDatePicker.getValue() != null) {
            contractList = contractList.stream()
                    .filter(contract -> contract.getEndDate() != null && !contract.getEndDate().isAfter(endDateDatePicker.getValue()))
                    .collect(Collectors.toList());
        }

        String contractType = contractTypeTextField.getText();
        if (!contractType.isEmpty()) {
            contractList = contractList.stream()
                    .filter(contract -> contract.getContractType().getContractType().toLowerCase().contains(contractType.toLowerCase()))
                    .collect(Collectors.toList());
        }

        ObservableList<Contract> contractObservableList = FXCollections.observableList(contractList);
        contractTableView.setItems(contractObservableList);
    }
}
