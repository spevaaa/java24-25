package hr.javafx.restaurant.spevec9.restaurant.model;

public abstract class Person extends Entity {
    private String firstName, lastName;
    private Contract contract;

    public Person(Long id, String firstName, String lastName, Contract contract) {
        super(id);
        this.firstName = firstName;
        this.lastName = lastName;
        this.contract = contract;
    }

    public Person(String firstName, String lastName, Contract contract) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.contract = contract;
    }

    public Person() {}

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }
}
