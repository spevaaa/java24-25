package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.exception.EmptyRepositoryResultException;
import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.Category;
import hr.javafx.restaurant.spevec9.restaurant.model.Database;
import hr.javafx.restaurant.spevec9.restaurant.model.Ingredient;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class IngredientRepository <T extends Ingredient> extends AbstractRepository<T> {

    @Override
    public List<T> findAll() {

        List<T> ingredients = new ArrayList<>();
        CategoriesRepository<Category> categoryRepository = new CategoriesRepository<>();

        try (Connection connection = Database.connectToDatabase()) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM INGREDIENT");

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                BigDecimal kcal = resultSet.getBigDecimal("kcal");
                String preparationMethod = resultSet.getString("preparation_method");

                Long categoryID = resultSet.getLong("category_id");
                Category category = categoryRepository.findById(categoryID);

                Ingredient ingredient = new Ingredient(id, name, category, kcal, preparationMethod);
                ingredients.add((T) ingredient);
            }

            return ingredients;
        } catch (SQLException | IOException e) {
            throw new RepositoryAccessException(e);
        }


    }

    @Override
    public T findById(Long id) {
        CategoriesRepository<Category> categoryRepository = new CategoriesRepository<>();
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement(
                    "SELECT * FROM INGREDIENT WHERE ID = ?;");
            stmt.setLong(1, id);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                Long resultId = resultSet.getLong("id");
                String name = resultSet.getString("name");
                BigDecimal kcal = resultSet.getBigDecimal("kcal");
                String preparationMethod = resultSet.getString("preparation_method");

                Long categoryID = resultSet.getLong("category_id");
                Category category = categoryRepository.findById(categoryID);

                Ingredient ingredient = new Ingredient(resultId, name, category, kcal, preparationMethod);
                return (T) ingredient;
            } else {
                throw new EmptyRepositoryResultException("Ingredient with id " + id + " not found");
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(List<T> entities) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement(
                    "INSERT INTO INGREDIENT(NAME, CATEGORY_ID, KCAL, PREPARATION_METHOD) VALUES(?, ?, ?, ?);");

            for (Ingredient ingredient : entities) {
                stmt.setString(1, ingredient.getName());
                stmt.setLong(2, ingredient.getCategory().getId());
                stmt.setBigDecimal(3, ingredient.getKcal());
                stmt.setString(4, ingredient.getPreparationMethod());
                stmt.executeUpdate();
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(T entity) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement(
                    "INSERT INTO INGREDIENT (NAME, CATEGORY_ID, KCAL, PREPARATION_METHOD) VALUES(?, ?, ?, ?);");
            stmt.setString(1, entity.getName());
            stmt.setLong(2, entity.getCategory().getId());
            stmt.setBigDecimal(3, entity.getKcal());
            stmt.setString(4, entity.getPreparationMethod());
            stmt.executeUpdate();

        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }
}
