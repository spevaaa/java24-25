package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.enumeration.ContractType;
import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.Bonus;
import hr.javafx.restaurant.spevec9.restaurant.model.Contract;
import hr.javafx.restaurant.spevec9.restaurant.model.Database;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ContractRepository<T extends Contract> extends AbstractRepository<T> {
    private static final String CONTRACTS_FILE_PATH = "dat/contracts.txt";

    @Override
    public List<T> findAll() {
        List<T> contracts = new ArrayList<>();

        try (Connection connection = Database.connectToDatabase()) {
            Statement stmt = connection.createStatement();
            ResultSet resultSet = stmt.executeQuery("SELECT * FROM CONTRACT;");

            while (resultSet.next()) {
                Long contractId = resultSet.getLong("id");
                BigDecimal salary = resultSet.getBigDecimal("salary");
                LocalDate startDate = resultSet.getDate("start_date").toLocalDate();
                LocalDate endDate = resultSet.getDate("end_date") == null ? null : resultSet.getDate("end_date").toLocalDate();
                String contractType = resultSet.getString("type");
                ContractType newContractType = ContractType.valueOf(contractType);

                Contract contract = new Contract(contractId, salary, startDate, endDate, newContractType);
                contracts.add((T) contract);
            }

            return contracts;
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }

    }

    @Override
    public T findById(Long id) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM CONTRACT WHERE ID = ?;");
            stmt.setLong(1, id);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                Long contractId = resultSet.getLong("id");
                BigDecimal salary = resultSet.getBigDecimal("salary");
                LocalDate startDate = resultSet.getDate("start_date").toLocalDate();
                LocalDate endDate = resultSet.getDate("end_date") == null ? null : resultSet.getDate("end_date").toLocalDate();
                String contractType = resultSet.getString("type");
                ContractType newContractType = ContractType.valueOf(contractType);
                return (T) new Contract(contractId, salary, startDate, endDate, newContractType);
            } else {
                throw new RepositoryAccessException("Contract with id " + id + " not found");
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(List<T> entities) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO CONTRACT (SALARY, BONUS, START_DATE, END_DATE, TYPE) VALUES (?, ?, ?, ?, ?);");

            for (Contract contract : entities) {
                stmt.setBigDecimal(1, contract.getSalary());
                stmt.setBigDecimal(2, BigDecimal.valueOf(200));
                stmt.setDate(3, Date.valueOf(contract.getStartDate()));
                stmt.setDate(4, Date.valueOf(contract.getEndDate()));
                stmt.setString(5, contract.getContractType().name());
                stmt.executeUpdate();
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(T entity) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO CONTRACT (SALARY, BONUS, START_DATE, END_DATE, TYPE) VALUES (?, ?, ?, ?, ?);");

            stmt.setBigDecimal(1, entity.getSalary());
            stmt.setBigDecimal(2, BigDecimal.valueOf(200));
            stmt.setDate(3, Date.valueOf(entity.getStartDate()));
            stmt.setDate(4, Date.valueOf(entity.getEndDate()));
            stmt.setString(5, entity.getContractType().name());
            stmt.executeUpdate();
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    private Long generateNewId() {
        return findAll().stream().map(i -> i.getId()).max((i1, i2) -> i1.compareTo(i2)).orElse(0l) + 1;
    }
}
