package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.Entity;

import java.util.List;

public abstract class AbstractRepository<T extends Entity> {
    public abstract List<T> findAll() throws RepositoryAccessException;
    public abstract T findById(Long id) throws RepositoryAccessException;
    public abstract void save(List<T> entities) throws RepositoryAccessException;
    public abstract void save(T entity) throws RepositoryAccessException;
}
