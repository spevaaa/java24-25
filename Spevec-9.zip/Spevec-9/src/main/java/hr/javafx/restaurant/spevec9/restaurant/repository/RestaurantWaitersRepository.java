package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

public class RestaurantWaitersRepository {
    public static Set<Waiter> getWaitersForRestaurant(Long restaurantId) {
        ContractRepository<Contract> contractRepository = new ContractRepository<>();
        Set<Waiter> waiters = new HashSet<>();

        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("""
                SELECT w.*
                FROM RESTAURANT_WAITER rw
                JOIN WAITER w ON rw.WAITER_ID = w.ID
                WHERE rw.RESTAURANT_ID = ?;
                """);

            stmt.setLong(1, restaurantId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Long waiterId = resultSet.getLong("id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                Contract contract = contractRepository.findById(resultSet.getLong("contract_id"));
                Bonus bonus = new Bonus(resultSet.getBigDecimal("BONUS"));
                Waiter waiter = new Waiter(waiterId, firstName, lastName, contract, bonus);
                waiters.add(waiter);
            }

            return waiters;
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    public static void saveWaitersForRestaurant(Restaurant restaurant) {
        try (Connection connection = Database.connectToDatabase()) {
            for (Waiter waiter : restaurant.getWaiters()) {
                PreparedStatement stmt = connection.prepareStatement("""
                    INSERT INTO RESTAURANT_WAITER (RESTAURANT_ID, WAITER_ID) VALUES (?, ?);
                    """);

                stmt.setLong(1, restaurant.getId());
                stmt.setLong(2, waiter.getId());
                stmt.executeUpdate();
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }
}
