package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RestaurantDeliverersRepository {

    public static void saveDeliverersForRestaurant(Restaurant restaurant) {
        try (Connection connection = Database.connectToDatabase()) {
            for (Deliverer deliverer : restaurant.getDeliverers()) {
                PreparedStatement stmt = connection.prepareStatement("""
                    INSERT INTO RESTAURANT_DELIVERER (RESTAURANT_ID, DELIVERER_ID) VALUES (?, ?);
                    """);

                stmt.setLong(1, restaurant.getId());
                stmt.setLong(2, deliverer.getId());
                stmt.executeUpdate();
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    public static Set<Deliverer> getDeliverersForRestaurant(Long restaurantId) {
        ContractRepository<Contract> contractRepository = new ContractRepository<>();
        Set<Deliverer> deliverers = new HashSet<>();

        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("""
                SELECT d.*
                FROM RESTAURANT_DELIVERER rd
                JOIN DELIVERER d ON rd.DELIVERER_ID = d.ID
                WHERE rd.RESTAURANT_ID = ?;
                """);

            stmt.setLong(1, restaurantId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Long delivererId = resultSet.getLong("id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                Contract contract = contractRepository.findById(resultSet.getLong("contract_id"));
                Bonus bonus = new Bonus(resultSet.getBigDecimal("BONUS"));
                Deliverer deliverer = new Deliverer(delivererId, firstName, lastName, contract, bonus);
                deliverers.add(deliverer);
            }

            return deliverers;
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }
}
