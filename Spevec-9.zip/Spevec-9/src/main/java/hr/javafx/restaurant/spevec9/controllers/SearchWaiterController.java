package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.restaurant.model.Waiter;
import hr.javafx.restaurant.spevec9.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.WaiterRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.util.List;
import java.util.stream.Collectors;

public class SearchWaiterController {
    @FXML
    private TextField employeeFirstNameTextField;
    @FXML
    private TextField employeeLastNameTextField;
    @FXML
    private TableView<Waiter> employeeTableView;
    @FXML
    private TableColumn<Waiter, String> employeeIdColumn;
    @FXML
    private TableColumn<Waiter, String> employeeFirstNameColumn;
    @FXML
    private TableColumn<Waiter, String> employeeLastNameColumn;
    @FXML
    private TableColumn<Waiter, String> employeeSalaryColumn;
    @FXML
    private TableColumn<Waiter, String> employeeBonusColumn;

    private AbstractRepository<Waiter> employeeRepository = new WaiterRepository();

    public void initialize() {
        employeeIdColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getId())));

        employeeFirstNameColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getFirstName()));

        employeeLastNameColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getLastName()));

        employeeSalaryColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getContract().getSalary())));

        employeeBonusColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getBonus().amount())));
    }

    public void filterEmployees() {
        List<Waiter> waiterList = employeeRepository.findAll();

        String employeeFirstName = employeeFirstNameTextField.getText();
        if(!employeeFirstName.isEmpty()) {
            waiterList = waiterList.stream()
                    .filter(employee -> employee.getFirstName().toLowerCase().contains(employeeFirstName.toLowerCase()))
                    .collect(Collectors.toList());
        }

        String employeeLastName = employeeLastNameTextField.getText();
        if(!employeeLastName.isEmpty()) {
            waiterList = waiterList.stream()
                    .filter(employee -> employee.getLastName().toLowerCase().contains(employeeLastName.toLowerCase()))
                    .collect(Collectors.toList());
        }

        ObservableList<Waiter> waiterObservableList = FXCollections.observableList(waiterList);
        employeeTableView.setItems(waiterObservableList);
    }
}
