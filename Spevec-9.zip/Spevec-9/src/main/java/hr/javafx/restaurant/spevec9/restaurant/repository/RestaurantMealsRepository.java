package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RestaurantMealsRepository {

    static CategoriesRepository<Category> categoryRepository = new CategoriesRepository<>();

    public static Set<Meal> getMealsForRestaurant(Long restaurantId) {
        Set<Meal> meals = new HashSet<>();

        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement("""
                SELECT m.*
                FROM RESTAURANT_MEAL rm
                JOIN MEAL m ON rm.MEAL_ID = m.ID
                WHERE rm.RESTAURANT_ID = ?;
                """);

            stmt.setLong(1, restaurantId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {

                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                Category category = categoryRepository.findById(resultSet.getLong("category_id"));
                BigDecimal price = resultSet.getBigDecimal("price");
                Set<Ingredient> ingredients = MealIngredientsRepository.getIngredientsForMeal(id);

                Meal meal = new Meal(id, name, category, ingredients, price);
                meals.add(meal);
            }

            return meals;
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    public static void saveMealsForRestaurant(Restaurant restaurant) {
        try (Connection connection = Database.connectToDatabase()) {
            for (Meal meal : restaurant.getMeals()) {
                PreparedStatement stmt = connection.prepareStatement("""
                    INSERT INTO RESTAURANT_MEAL (RESTAURANT_ID, MEAL_ID) VALUES (?, ?);
                    """);

                stmt.setLong(1, restaurant.getId());
                stmt.setLong(2, meal.getId());
                stmt.executeUpdate();
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }
}
