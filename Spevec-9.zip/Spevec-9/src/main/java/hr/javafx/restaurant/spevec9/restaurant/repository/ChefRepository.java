package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.enumeration.ContractType;
import hr.javafx.restaurant.spevec9.restaurant.exception.EmptyRepositoryResultException;
import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ChefRepository<T extends Chef> extends AbstractRepository<T> {

    @Override
    public List<T> findAll() {

        List<T> chefs = new ArrayList<>();
        ContractRepository<Contract> contractRepository = new ContractRepository<>();

        try (Connection connection = Database.connectToDatabase()) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM CHEF");

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                BigDecimal bonus = resultSet.getBigDecimal("bonus");
                Bonus newBonus = new Bonus(bonus);
                Long contractId = resultSet.getLong("contract_id");

                Contract contract = contractRepository.findById(contractId);
                Chef chef = new Chef(id, firstName, lastName, contract, newBonus);
                chefs.add((T) chef);
            }

            return chefs;
        } catch (SQLException | IOException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public T findById(Long id) {

        ContractRepository<Contract> contractRepository = new ContractRepository<>();
        try (Connection connection = Database.connectToDatabase()) {

            PreparedStatement stmt = connection.prepareStatement(
                    "SELECT * FROM CHEF WHERE ID = ?;");
            stmt.setLong(1, id);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                Long chefId = resultSet.getLong("id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                BigDecimal bonus = resultSet.getBigDecimal("bonus");
                Bonus newBonus = new Bonus(bonus);
                Long contractId = resultSet.getLong("contract_id");

                Contract contract = contractRepository.findById(contractId);
                Chef chef = new Chef(chefId, firstName, lastName, contract, newBonus);
                return (T) chef;

            } else {
                throw new EmptyRepositoryResultException("Chef with id " + id + " not found");
            }

        } catch (SQLException | IOException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(List<T> entities) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement(
                    "INSERT INTO CHEF (FIRST_NAME, LAST_NAME, CONTRACT_ID, BONUS) VALUES (?, ?, ?, ?);");

            for (Chef chef : entities) {
                stmt.setString(1, chef.getFirstName());
                stmt.setString(2, chef.getLastName());
                stmt.setLong(3, chef.getContract().getId());
                stmt.setBigDecimal(4, chef.getBonus().amount());
                stmt.executeUpdate();
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(T entity) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement(
                    "INSERT INTO CHEF (FIRST_NAME, LAST_NAME, CONTRACT_ID, BONUS) VALUES (?, ?, ?, ?);");
            stmt.setString(1, entity.getFirstName());
            stmt.setString(2, entity.getLastName());
            stmt.setLong(3, entity.getContract().getId());
            stmt.setBigDecimal(4, entity.getBonus().amount());
            stmt.executeUpdate();
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    private Long generateNewId() {
        return findAll().stream().map(i -> i.getId())
                .max((i1, i2) -> i1.compareTo(i2)).orElse(0l) + 1;
    }
}
