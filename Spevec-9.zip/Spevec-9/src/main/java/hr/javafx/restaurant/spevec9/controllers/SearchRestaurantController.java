package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.restaurant.model.Meal;
import hr.javafx.restaurant.spevec9.restaurant.model.Restaurant;
import hr.javafx.restaurant.spevec9.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.RestaurantRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.util.List;
import java.util.stream.Collectors;

public class SearchRestaurantController {

    @FXML
    private TextField restaurantNameTextField;
    @FXML
    private TextField restaurantCityTextField;
    @FXML
    private TextField mealTextField;
    @FXML
    private TextField chefFirstNameTextField;
    @FXML
    private TextField chefLastNameTextField;
    @FXML
    private TextField waiterFirstNameTextField;
    @FXML
    private TextField waiterLastNameTextField;
    @FXML
    private TextField delivererFirstNameTextField;
    @FXML
    private TextField delivererLastNameTextField;

    @FXML
    private TableView<Restaurant> restaurantTableView;
    @FXML
    private TableColumn<Restaurant, String> restaurantIdColumn;
    @FXML
    private TableColumn<Restaurant, String> restaurantNameColumn;
    @FXML
    private TableColumn<Restaurant, String> restaurantCityColumn;
    @FXML
    private TableColumn<Restaurant, String> restaurantMealsColumn;
    @FXML
    private TableColumn<Restaurant, String> restaurantChefsColumn;
    @FXML
    private TableColumn<Restaurant, String> restaurantWaitersColumn;
    @FXML
    private TableColumn<Restaurant, String> restaurantDeliverersColumn;

    private AbstractRepository<Restaurant> restaurantRepository = new RestaurantRepository<>();

    public void initialize() {

        restaurantIdColumn.setCellValueFactory(cellDate ->
                new SimpleStringProperty(String.valueOf(cellDate.getValue().getId())));

        restaurantNameColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getName()));

        restaurantCityColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getAddress().getCity()));

        restaurantMealsColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMeals().stream()
                        .map(Meal::getName)
                        .collect(Collectors.joining(", "))));

        restaurantChefsColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getChefs().stream()
                        .map(chef -> chef.getFirstName() + " " + chef.getLastName())
                        .collect(Collectors.joining(", "))));

        restaurantWaitersColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getWaiters().stream()
                        .map(waiter -> waiter.getFirstName() + " " + waiter.getLastName())
                        .collect(Collectors.joining(", "))));

        restaurantDeliverersColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getDeliverers().stream()
                        .map(deliverer -> deliverer.getFirstName() + " " + deliverer.getLastName())
                        .collect(Collectors.joining(", "))));
    }

    public void filterRestaurants() {


        List<Restaurant> restaurantList = restaurantRepository.findAll();
        String restaurantName = restaurantNameTextField.getText();

        if (!restaurantName.isEmpty()) {
            restaurantList = restaurantList.stream().filter(restaurant -> restaurant.getName().toLowerCase()
                    .contains(restaurantName.toLowerCase()))
                    .collect(Collectors.toList());
        }

        String restaurantCity = restaurantCityTextField.getText();
        if (!restaurantCity.isEmpty()) {
            restaurantList = restaurantList.stream().filter(restaurant -> restaurant.getAddress().getCity().toLowerCase()
                    .contains(restaurantCity.toLowerCase())).collect(Collectors.toList());
        }

        String restaurantMeals = mealTextField.getText();
        if (!restaurantMeals.isEmpty()) {
            restaurantList = restaurantList.stream().filter(restaurant -> restaurant.getMeals().stream()
                            .anyMatch(meal -> meal.getName().toLowerCase().contains(restaurantMeals.toLowerCase())))
                    .collect(Collectors.toList());
        }

        String restaurantChefsFirstName = chefFirstNameTextField.getText();
        if (!restaurantChefsFirstName.isEmpty()) {
            restaurantList = restaurantList.stream().filter(restaurant -> restaurant.getChefs().stream()
                            .anyMatch(chef -> chef.getFirstName().toLowerCase().contains(restaurantChefsFirstName.toLowerCase())))
                    .collect(Collectors.toList());
        }

        String restaurantChefsLastName = chefLastNameTextField.getText();
        if (!restaurantChefsLastName.isEmpty()) {
            restaurantList = restaurantList.stream().filter(restaurant -> restaurant.getChefs().stream()
                            .anyMatch(chef -> chef.getLastName().toLowerCase().contains(restaurantChefsLastName.toLowerCase())))
                    .collect(Collectors.toList());
        }

        String restaurantWaitersFirstName = waiterFirstNameTextField.getText();
        if (!restaurantWaitersFirstName.isEmpty()) {
            restaurantList = restaurantList.stream().filter(restaurant -> restaurant.getWaiters().stream()
                            .anyMatch(waiter -> waiter.getFirstName().toLowerCase().contains(restaurantWaitersFirstName.toLowerCase())))
                    .collect(Collectors.toList());
        }

        String restaurantWaitersLastName = waiterLastNameTextField.getText();
        if (!restaurantWaitersLastName.isEmpty()) {
            restaurantList = restaurantList.stream().filter(restaurant -> restaurant.getWaiters().stream()
                            .anyMatch(waiter -> waiter.getLastName().toLowerCase().contains(restaurantWaitersLastName.toLowerCase())))
                    .collect(Collectors.toList());
        }

        String delivererFirstName = delivererFirstNameTextField.getText();
        if (!delivererFirstName.isEmpty()) {
            restaurantList = restaurantList.stream().filter(restaurant -> restaurant.getDeliverers().stream()
                            .anyMatch(deliverer -> deliverer.getFirstName().toLowerCase().contains(delivererFirstName.toLowerCase())))
                    .collect(Collectors.toList());
        }

        String delivererLastName = delivererLastNameTextField.getText();
        if (!delivererLastName.isEmpty()) {
            restaurantList = restaurantList.stream().filter(restaurant -> restaurant.getDeliverers().stream()
                            .anyMatch(deliverer -> deliverer.getLastName().toLowerCase().contains(delivererLastName.toLowerCase())))
                    .collect(Collectors.toList());
        }

        ObservableList<Restaurant> restaurantObservableList = FXCollections.observableList(restaurantList);
        restaurantTableView.setItems(restaurantObservableList);

    }
}
