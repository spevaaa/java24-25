package hr.javafx.restaurant.spevec9.restaurant.repository;

import hr.javafx.restaurant.spevec9.restaurant.exception.EmptyRepositoryResultException;
import hr.javafx.restaurant.spevec9.restaurant.exception.RepositoryAccessException;
import hr.javafx.restaurant.spevec9.restaurant.model.Category;
import hr.javafx.restaurant.spevec9.restaurant.model.Database;
import hr.javafx.restaurant.spevec9.restaurant.model.Ingredient;
import hr.javafx.restaurant.spevec9.restaurant.model.Meal;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

public class MealRepository<T extends Meal> extends AbstractRepository<T> {

    @Override
    public List<T> findAll() {
        List<T> meals = new ArrayList<>();
        CategoriesRepository<Category> categoryRepository = new CategoriesRepository<>();
        IngredientRepository<Ingredient> ingredientRepository = new IngredientRepository<>();

        try (Connection connection = Database.connectToDatabase()) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM MEAL");

            while (resultSet.next()) {
                Set<Ingredient> ingredients = new HashSet<>();

                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                Long categoryID = resultSet.getLong("category_id");
                Category category = categoryRepository.findById(categoryID);
                BigDecimal price = resultSet.getBigDecimal("price");

                Statement ingredientStatement = connection.createStatement();
                ResultSet ingredientResultSet = ingredientStatement.executeQuery("SELECT INGREDIENT_ID FROM MEAL_INGREDIENT WHERE MEAL_ID = " + id);

                while (ingredientResultSet.next()) {
                    Long ingredientID = ingredientResultSet.getLong("ingredient_id");
                    Ingredient ingredient = ingredientRepository.findById(ingredientID);
                    ingredients.add(ingredient);
                }

                Meal meal = new Meal(id, name, category, ingredients, price);
                meals.add((T) meal);
            }

            return meals;
        } catch (SQLException | IOException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public T findById(Long id) {
        CategoriesRepository<Category> categoryRepository = new CategoriesRepository<>();
        IngredientRepository<Ingredient> ingredientRepository = new IngredientRepository<>();

        try (Connection connection = Database.connectToDatabase()){

            PreparedStatement stmt = connection.prepareStatement(
                    "SELECT * FROM MEAL WHERE ID = ?;");
            stmt.setLong(1, id);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                Set<Ingredient> ingredients = new HashSet<>();

                Long mealId = resultSet.getLong("id");
                String name = resultSet.getString("name");
                Long categoryID = resultSet.getLong("category_id");
                Category category = categoryRepository.findById(categoryID);
                BigDecimal price = resultSet.getBigDecimal("price");

                Statement ingredientStatement = connection.createStatement();
                ResultSet ingredientResultSet = ingredientStatement.executeQuery("SELECT INGREDIENT_ID FROM MEAL_INGREDIENT WHERE MEAL_ID = " + id);

                while (ingredientResultSet.next()) {
                    Long ingredientID = ingredientResultSet.getLong("ingredient_id");
                    Ingredient ingredient = ingredientRepository.findById(ingredientID);
                    ingredients.add(ingredient);
                }

                Meal meal = new Meal(mealId, name, category, ingredients, price);
                return (T) meal;
            } else {
                throw new EmptyRepositoryResultException("Meal with id " + id + " not found");
            }

        }catch (SQLException | IOException e) {
            throw new RepositoryAccessException(e);
        }

    }

    @Override
    public void save(List<T> entities) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement(
                    "INSERT INTO MEAL(NAME, CATEGORY_ID, PRICE) VALUES(?, ?, ?);");

            for (Meal meal : entities) {
                stmt.setString(1, meal.getName());
                stmt.setLong(2, meal.getCategory().getId());
                stmt.setBigDecimal(3, meal.getPrice());
                stmt.executeUpdate();
            }
        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    @Override
    public void save(T entity) {
        try (Connection connection = Database.connectToDatabase()) {
            PreparedStatement stmt = connection.prepareStatement(
                    "INSERT INTO MEAL(NAME, CATEGORY_ID, PRICE) VALUES(?, ?, ?);");
            stmt.setString(1, entity.getName());
            stmt.setLong(2, entity.getCategory().getId());
            stmt.setBigDecimal(3, entity.getPrice());
            stmt.executeUpdate();

        } catch (IOException | SQLException e) {
            throw new RepositoryAccessException(e);
        }
    }

    private Long generateNewId() {
        return findAll().stream().map(i -> i.getId())
                .max((i1, i2) -> i1.compareTo(i2)).orElse(0l) + 1;
    }
}
