package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.restaurant.model.Address;
import hr.javafx.restaurant.spevec9.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.AddressRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.util.List;
import java.util.stream.Collectors;

public class SearchAddressController {
    @FXML
    private TextField addressStreetTextField;
    @FXML
    private TextField addressHouseNumberTextField;
    @FXML
    private TextField addressCityTextField;
    @FXML
    private TextField addressPostalCodeTextField;
    @FXML
    private TableView<Address> addressTableView;
    @FXML
    private TableColumn<Address, String> addressIdColumn, addressStreetColumn, addressHouseNumberColumn, addressCityColumn, addressPostalCodeColumn;

    private AbstractRepository<Address> addressRepository = new AddressRepository();

    public void initialize() {
        addressIdColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getId())));

        addressStreetColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getStreet()));

        addressHouseNumberColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getHouseNumber()));

        addressCityColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getCity()));

        addressPostalCodeColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getPostalCode()));
    }

    public void filterAddresses() {
        List<Address> addressList = addressRepository.findAll();

        String addressStreet = addressStreetTextField.getText();
        if(!addressStreet.isEmpty()) {
            addressList = addressList.stream()
                    .filter(address -> address.getStreet().toLowerCase().contains(addressStreet.toLowerCase()))
                    .collect(Collectors.toList());
        }

        String addressHouseNumber = addressHouseNumberTextField.getText();
        if(!addressHouseNumber.isEmpty()) {
            addressList = addressList.stream()
                    .filter(address -> address.getHouseNumber().toLowerCase().contains(addressHouseNumber.toLowerCase()))
                    .collect(Collectors.toList());
        }

        String addressCity = addressCityTextField.getText();
        if(!addressCity.isEmpty()) {
            addressList = addressList.stream()
                    .filter(address -> address.getCity().toLowerCase().contains(addressCity.toLowerCase()))
                    .collect(Collectors.toList());
        }

        String addressPostalCode = addressPostalCodeTextField.getText();
        if(!addressPostalCode.isEmpty()) {
            addressList = addressList.stream()
                    .filter(address -> address.getPostalCode().toLowerCase().contains(addressPostalCode.toLowerCase()))
                    .collect(Collectors.toList());
        }

        ObservableList<Address> observableList = FXCollections.observableList(addressList);
        addressTableView.setItems(observableList);
    }
}
