package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.restaurant.model.Category;
import hr.javafx.restaurant.spevec9.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.CategoriesRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.util.List;
import java.util.stream.Collectors;

public class SearchCategoryController {
    @FXML
    private TextField categoryNameTextField;
    @FXML
    private TableView<Category> categoryTableView;
    @FXML
    private TableColumn<Category, String> categoryIdColumn;
    @FXML
    private TableColumn<Category, String> categoryNameColumn;
    @FXML
    private TableColumn<Category, String> categoryDescriptionColumn;

    private AbstractRepository<Category> categoryRepository = new CategoriesRepository();
    private List<Category> categories = categoryRepository.findAll();

    public void initialize() {
        categoryIdColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getId())));

        categoryNameColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getName()));

        categoryDescriptionColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getDescription()));
    }

    public void filterCategories() {
        List<Category> categoryList = categoryRepository.findAll();

        String categoryName = categoryNameTextField.getText();
        if(!categoryName.isEmpty()) {
            categoryList = categoryList.stream()
                    .filter(category -> category.getName().toLowerCase().contains(categoryName.toLowerCase()))
                    .collect(Collectors.toList());
        }

        ObservableList<Category> categoryObservableList = FXCollections.observableList(categoryList);
        categoryTableView.setItems(categoryObservableList);
    }
}
