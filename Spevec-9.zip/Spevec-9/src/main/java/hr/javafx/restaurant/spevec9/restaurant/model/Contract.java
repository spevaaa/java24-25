package hr.javafx.restaurant.spevec9.restaurant.model;

import hr.javafx.restaurant.spevec9.restaurant.enumeration.ContractType;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Contract extends Entity {

    private String name;
    private BigDecimal salary;
    private LocalDate startDate, endDate;
    private ContractType contractType;

    public Contract(String name, BigDecimal salary, LocalDate startDate, LocalDate endDate, ContractType contractType) {
        this.name = name;
        this.salary = salary;
        this.startDate = startDate;
        this.endDate = endDate;
        this.contractType = contractType;
    }


    public Contract(Long id, BigDecimal salary, LocalDate startDate, LocalDate endDate, ContractType contractType) {
        super(id);
        this.salary = salary;
        this.startDate = startDate;
        this.endDate = endDate;
        this.contractType = contractType;
    }

    public Contract(BigDecimal salary, LocalDate startDate, LocalDate endDate, ContractType contractType) {
        this.salary = salary;
        this.startDate = startDate;
        this.endDate = endDate;
        this.contractType = contractType;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public ContractType getContractType() {
        return contractType;
    }

    public void setContractType(ContractType contractType) {
        this.contractType = contractType;
    }


}
