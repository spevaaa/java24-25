package hr.javafx.restaurant.spevec9.controllers;

import hr.javafx.restaurant.spevec9.main.Main;
import hr.javafx.restaurant.spevec9.restaurant.model.Address;
import hr.javafx.restaurant.spevec9.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec9.restaurant.repository.AddressRepository;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;

import java.io.IOException;

public class AddAddressController {
    @FXML
    private TextField newAddressStreetTextField;
    @FXML
    private TextField newAddressCityTextField;
    @FXML
    private TextField newAddressHouseNumberTextField;
    @FXML
    private TextField newAddressPostalCodeTextField;

    private AbstractRepository<Address> addressRepository = new AddressRepository();

    public void initialize() {}

    public void addAddress(){
        String street = newAddressStreetTextField.getText();
        String city = newAddressCityTextField.getText();
        String houseNumber = newAddressHouseNumberTextField.getText();
        String postalCode = newAddressPostalCodeTextField.getText();

        Address address = new Address(street, houseNumber, city, postalCode);
        addressRepository.save(address);

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec9/showAddresses.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
