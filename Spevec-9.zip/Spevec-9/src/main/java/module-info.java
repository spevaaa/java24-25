module hr.javafx.restaurant.spevec9 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens hr.javafx.restaurant.spevec9 to javafx.fxml;
    exports hr.javafx.restaurant.spevec9.controllers;
    opens hr.javafx.restaurant.spevec9.controllers to javafx.fxml;
    exports hr.javafx.restaurant.spevec9.main;
    opens hr.javafx.restaurant.spevec9.main to javafx.fxml;
}