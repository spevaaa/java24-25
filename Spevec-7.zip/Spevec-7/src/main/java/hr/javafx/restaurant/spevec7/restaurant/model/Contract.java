package hr.javafx.restaurant.spevec7.restaurant.model;

import hr.javafx.restaurant.spevec7.restaurant.enumeration.ContractType;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Contract extends Entity {
    private static Long idCounter = 0L;

    private BigDecimal salary;
    private LocalDate startDate, endDate;
    private ContractType contractType;
    private boolean active;

    public Contract(Long id, BigDecimal salary, LocalDate startDate, LocalDate endDate, ContractType contractType) {
        super(id);
        this.salary = salary;
        this.startDate = startDate;
        this.endDate = endDate;
        this.contractType = contractType;
        idCounter++;
    }

    public Contract(BigDecimal salary, LocalDate startDate, LocalDate endDate, ContractType contractType) {
        super(++idCounter);
        this.salary = salary;
        this.startDate = startDate;
        this.endDate = endDate;
        this.contractType = contractType;
    }

    public Contract(BigDecimal salary, LocalDate startDate, LocalDate endDate, ContractType contractType, boolean active) {
        super(++idCounter);
        this.salary = salary;
        this.startDate = startDate;
        this.endDate = endDate;
        this.contractType = contractType;
        this.active = active;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public ContractType getContractType() {
        return contractType;
    }

    public void setContractType(ContractType contractType) {
        this.contractType = contractType;
    }


}
