package hr.javafx.restaurant.spevec7.controllers;

import hr.javafx.restaurant.spevec7.restaurant.model.Meal;
import hr.javafx.restaurant.spevec7.restaurant.model.Order;
import hr.javafx.restaurant.spevec7.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.OrderRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.util.List;
import java.util.stream.Collectors;

public class SearchOrderController {

    @FXML
    public TextField restaurantNameTextField;
    @FXML
    public TextField mealTextField;
    @FXML
    public TextField delivererFirstNameTextField;
    @FXML
    public TextField delivererLastNameTextField;

    @FXML
    public TableColumn<Order, String> orderIdColumn;
    @FXML
    public TableColumn<Order, String> orderRestaurantNameColumn;
    @FXML
    public TableColumn<Order, String> orderMealsColumn;
    @FXML
    public TableColumn<Order, String> orderDelivererColumn;
    @FXML
    public TableColumn<Order, String> orderDateColumn;
    @FXML
    public TableView<Order> orderTableView;

    private AbstractRepository<Order> orderRepository = new OrderRepository<>();

    public void initialize() {
        orderIdColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getId())));

        orderRestaurantNameColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getRestaurant().getName()));

        orderMealsColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMeals().stream()
                        .map(Meal::getName)
                        .collect(Collectors.joining(", "))));

        orderDelivererColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getDeliverer().getFirstName() + " " + cellData.getValue().getDeliverer().getLastName()));

        orderDateColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getDeliveryDateAndTime())));
    }

    public void filterOrders() {
        List<Order> ordersList = orderRepository.findAll();

        String restaurantName = restaurantNameTextField.getText();
        if(!restaurantName.isEmpty()) {
            ordersList = ordersList.stream()
                    .filter(order -> order.getRestaurant().getName().toLowerCase().contains(restaurantName.toLowerCase()))
                    .collect(Collectors.toList());
        }


        String mealName = mealTextField.getText();
        if(!mealName.isEmpty()) {
            ordersList = ordersList.stream()
                    .filter(order -> order.getMeals().stream()
                            .anyMatch(meal -> meal.getName().toLowerCase().contains(mealName.toLowerCase())))
                    .collect(Collectors.toList());
        }


        String delivererFirstName = delivererFirstNameTextField.getText();
        if (!delivererFirstName.isEmpty()) {
            ordersList = ordersList.stream()
                    .filter(order -> order.getDeliverer().getFirstName().toLowerCase().contains(delivererFirstName.toLowerCase()))
                    .collect(Collectors.toList());
        }


        String delivererLastName = delivererLastNameTextField.getText();
        if (!delivererLastName.isEmpty()) {
            ordersList = ordersList.stream()
                    .filter(order -> order.getDeliverer().getLastName().toLowerCase().contains(delivererLastName.toLowerCase()))
                    .collect(Collectors.toList());
        }

        ObservableList<Order> orderObservableList = FXCollections.observableList(ordersList);
        orderTableView.setItems(orderObservableList);

    }
}
