package hr.javafx.restaurant.spevec7.restaurant.model;

import java.util.Objects;

public class Chef extends Person {
    private Bonus bonus;

    public Chef(Long id, String firstName, String lastName, Contract contract, Bonus bonus) {
        super(id, firstName, lastName, contract);
        this.bonus = bonus;
    }

    public Bonus getBonus() {
        return bonus;
    }

    public void setBonus(Bonus bonus) {
        this.bonus = bonus;
    }

    public static class Builder {
        private String firstName;
        private String lastName;
        private Contract contract;
        private Bonus bonus;

        public Builder withFirstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder withLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder withContract(Contract contract) {
            this.contract = contract;
            return this;
        }

        public Builder withBonus(Bonus bonus) {
            this.bonus = bonus;
            return this;
        }

        public Chef build() {
            Chef chef = new Chef();

            chef.setFirstName(this.firstName);
            chef.setLastName(this.lastName);
            chef.setContract(this.contract);
            chef.setBonus(this.bonus);

            return chef;
        }
    }

    private Chef() {}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Chef chef = (Chef) o;
        return Objects.equals(getFirstName(), chef.getFirstName()) &&
                Objects.equals(getLastName(), chef.getLastName()) &&
                Objects.equals(getContract(), chef.getContract()) &&
                Objects.equals(bonus, chef.bonus);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFirstName(), getLastName(), getContract(), bonus);
    }

}
