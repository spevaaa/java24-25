package hr.javafx.restaurant.spevec7.restaurant.repository;

import hr.javafx.restaurant.spevec7.restaurant.model.Category;
import hr.javafx.restaurant.spevec7.restaurant.model.Ingredient;
import hr.javafx.restaurant.spevec7.restaurant.model.Meal;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MealRepository<T extends Meal> extends AbstractRepository<T> {
    private static final String MEALS_FILE_PATH = "dat/meals.txt";
    private static final Integer NUMBER_OF_ROWS_PER_MEAL = 5;

    @Override
    public List<T> findAll() {
        List<T> meals = new ArrayList<>();
        CategoriesRepository categoriesRepository = new CategoriesRepository();
        IngredientRepository ingredientRepository = new IngredientRepository();

        try (Stream<String> stream = Files.lines(Path.of(MEALS_FILE_PATH))) {
            List<String> fileRows = stream.collect(Collectors.toList());

            for (Integer recordNumber = 0; recordNumber < (fileRows.size() / NUMBER_OF_ROWS_PER_MEAL); recordNumber++) {
                Long id = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_MEAL));
                String name = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_MEAL + 1);

                Long categoryId = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_MEAL + 2));
                Category category = categoriesRepository.findById(categoryId);

                String ingredientsIds = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_MEAL + 3);
                Set<Ingredient> ingredients = Arrays.stream(ingredientsIds.split(","))
                        .map(idString -> Long.parseLong(idString))
                        .map(idLong -> ingredientRepository.findById(idLong))
                        .collect(Collectors.toSet());

                BigDecimal price = new BigDecimal(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_MEAL + 4));

                Meal meal = new Meal(id, name, category, ingredients, price);
                meals.add((T) meal);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return meals;
    }

    @Override
    public T findById(Long id) {
        return findAll().stream().filter(entity -> entity.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public void save(List<T> entities) {
        try (PrintWriter writer = new PrintWriter(MEALS_FILE_PATH)) {
            for (T entity : entities) {
                writer.println(entity.getId());
                writer.println(entity.getName());
                writer.println(entity.getCategory().getId());

                StringBuilder ingredientBuilder = new StringBuilder();
                for(Ingredient ingredient : entity.getIngredients()) {
                    ingredientBuilder = ingredientBuilder.append(ingredient.getId()).append(",");
                }
                writer.println(ingredientBuilder);

                writer.println(entity.getPrice());
            }
            writer.flush();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void save(T entity) {

    }
}
