package hr.javafx.restaurant.spevec7.restaurant.model;

public class Category extends Entity {

    private String name, description;

    public Category(Long id, String name, String description) {
        super(id);
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public static class Builder {
        private Long id;
        private String name, description;

        public Builder (Long id) {
            this.id = id;
        }

        public Builder withName(String name) {
            this.name = name;
            return this;
        }

        public Builder withDescription(String description) {
            this.description = description;
            return this;
        }

        public Category build() {
            Category category = new Category();

            category.setId(id);
            category.setName(name);
            category.setDescription(description);

            return category;
        }
    }

    private Category() {}
}
