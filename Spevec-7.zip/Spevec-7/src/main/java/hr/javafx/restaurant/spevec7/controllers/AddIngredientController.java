package hr.javafx.restaurant.spevec7.controllers;

import hr.javafx.restaurant.spevec7.main.Main;
import hr.javafx.restaurant.spevec7.restaurant.model.Category;
import hr.javafx.restaurant.spevec7.restaurant.model.Ingredient;
import hr.javafx.restaurant.spevec7.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.CategoriesRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.IngredientRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

public class AddIngredientController {
    @FXML
    private TextField newIngredientNameTextField;
    @FXML
    private ComboBox<String> ingredientCategoryComboBox;
    @FXML
    private TextField newIngredientKcalTextField;
    @FXML
    private TextField newIngredientPrepMethod;

    private AbstractRepository<Category> categoryRepository = new CategoriesRepository();
    private List<Category> categories = categoryRepository.findAll();
    private ObservableList<String> categoryObservableList = FXCollections.observableArrayList(categories.stream().map(Category::getName).collect(Collectors.toList()));

    private AbstractRepository<Ingredient> ingredientRepository = new IngredientRepository();

    public void initialize() {
        ingredientCategoryComboBox.setItems(categoryObservableList);
    }

    public void addIngredient() {
        String name = newIngredientNameTextField.getText();

        String categoryName = ingredientCategoryComboBox.getValue();
        Category category = categories.stream().filter(c -> c.getName().equals(categoryName)).findFirst().orElse(null);

        String kcalString = newIngredientKcalTextField.getText();
        BigDecimal kcal = new BigDecimal(kcalString);

        String prepMethod = newIngredientPrepMethod.getText();

        Ingredient ingredient = new Ingredient(name, category, kcal, prepMethod);
        ingredientRepository.save(ingredient);

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec7/showIngredients.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
