package hr.javafx.restaurant.spevec7.restaurant.repository;

import hr.javafx.restaurant.spevec7.restaurant.model.Bonus;
import hr.javafx.restaurant.spevec7.restaurant.model.Contract;
import hr.javafx.restaurant.spevec7.restaurant.model.Deliverer;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DelivererRepository<T extends Deliverer> extends AbstractRepository<T> {
    private static final String DELIVERERS_FILE_PATH = "dat/deliverers.txt";
    private static final Integer NUMBER_OF_ROWS_PER_DELIVERER = 5;

    @Override
    public List<T> findAll() {
        List<T> deliverers = new ArrayList<>();
        ContractRepository contractRepository = new ContractRepository();

        try (Stream<String> stream = Files.lines(Path.of(DELIVERERS_FILE_PATH))) {
            List<String> fileRows = stream.collect(Collectors.toList());

            for (Integer recordNumber = 0; recordNumber < (fileRows.size() / NUMBER_OF_ROWS_PER_DELIVERER); recordNumber++) {
                Long id = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_DELIVERER));
                String firstName = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_DELIVERER + 1);
                String lastName = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_DELIVERER + 2);

                Long contractId = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_DELIVERER + 3));
                Contract contract = contractRepository.findById(contractId);

                BigDecimal bonusAmout = new BigDecimal(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_DELIVERER + 4));
                Bonus bonus = new Bonus(bonusAmout);

                Deliverer deliverer = new Deliverer(id, firstName, lastName, contract, bonus);
                deliverers.add((T) deliverer);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return deliverers;
    }

    @Override
    public T findById(Long id) {
        return findAll().stream().filter(entity -> entity.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public void save(List<T> entities) {
        try (PrintWriter writer = new PrintWriter(DELIVERERS_FILE_PATH)) {
            for (T entity : entities) {
                writer.println(entity.getId());
                writer.println(entity.getFirstName());
                writer.println(entity.getLastName());
                writer.println(entity.getContract().getId());
                writer.println(entity.getBonus().amount());
            }
            writer.flush();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void save(T entity) {

    }
}

