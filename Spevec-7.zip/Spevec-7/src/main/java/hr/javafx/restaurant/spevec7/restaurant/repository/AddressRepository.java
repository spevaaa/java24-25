package hr.javafx.restaurant.spevec7.restaurant.repository;

import hr.javafx.restaurant.spevec7.restaurant.model.Address;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AddressRepository <T extends Address> extends AbstractRepository<T> {
    private static final String ADDRESS_FILE_PATH = "dat/addresses.txt";
    private static final Integer NUMBER_OF_ROWS_PER_ADDRESS = 5;

    @Override
    public List<T> findAll() {
        List<T> addresses = new ArrayList<>();

        try (Stream<String> stream = Files.lines(Path.of(ADDRESS_FILE_PATH))) {
            List<String> fileRows = stream.collect(Collectors.toList());

            for (Integer recordNumber = 0; recordNumber < (fileRows.size() / NUMBER_OF_ROWS_PER_ADDRESS); recordNumber++) {
                Long id = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_ADDRESS));
                String street = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_ADDRESS + 1);
                String houseNumber = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_ADDRESS + 2);
                String city = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_ADDRESS + 3);
                String postalCode = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_ADDRESS + 4);

                Address address = new Address(id, street, houseNumber, city, postalCode);
                addresses.add((T) address);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return addresses;
    }

    @Override
    public T findById(Long id) {
        return findAll().stream().filter(entity -> entity.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public void save(List<T> entities) {
        try (PrintWriter writer = new PrintWriter(ADDRESS_FILE_PATH)) {
            for (T entity : entities) {
                writer.println(entity.getId());
                writer.println(entity.getStreet());
                writer.println(entity.getHouseNumber());
                writer.println(entity.getCity());
                writer.println(entity.getPostalCode());
            }
            writer.flush();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void save(T entity) {

    }
}
