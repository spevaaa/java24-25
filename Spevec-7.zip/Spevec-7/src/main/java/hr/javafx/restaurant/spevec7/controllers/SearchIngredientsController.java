package hr.javafx.restaurant.spevec7.controllers;

import hr.javafx.restaurant.spevec7.restaurant.model.Category;
import hr.javafx.restaurant.spevec7.restaurant.model.Ingredient;
import hr.javafx.restaurant.spevec7.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.CategoriesRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.IngredientRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

public class SearchIngredientsController {
    @FXML
    private TextField ingredientNameTextField;
    @FXML
    private TableView<Ingredient> ingredientTableView;
    @FXML
    private TableColumn<Ingredient, String> ingredientIdColumn;
    @FXML
    private TableColumn<Ingredient, String> ingredientNameColumn;
    @FXML
    private TableColumn<Ingredient, String> ingredientCategoryColumn;
    @FXML
    private TableColumn<Ingredient, String> ingredientKcalColumn;
    @FXML
    private TableColumn<Ingredient, String> ingredientPrepMethodColumn;
    @FXML
    private ComboBox<String> ingredientCategoryComboBox;
    @FXML
    private TextField kcalTextField;

    private AbstractRepository<Ingredient> ingredientRepository = new IngredientRepository();

    private AbstractRepository<Category> categoryRepository = new CategoriesRepository();
    private List<Category> categories = categoryRepository.findAll();
    private ObservableList<String> categoryObservableList = FXCollections.observableArrayList(categories.stream().map(Category::getName).collect(Collectors.toList()));

    public void initialize() {
        ingredientIdColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getId())));

        ingredientNameColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getName()));

        ingredientCategoryColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getCategory().getName()));

        ingredientKcalColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getKcal())));

        ingredientPrepMethodColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getPreparationMethod()));

        ingredientCategoryComboBox.setItems(categoryObservableList);

    }

    public void filterIngredients() {
        List<Ingredient> ingredientList = ingredientRepository.findAll();

        String ingredientName = ingredientNameTextField.getText();
        if(!ingredientName.isEmpty()) {
            ingredientList = ingredientList.stream()
                    .filter(ingredient -> ingredient.getName().toLowerCase().contains(ingredientName.toLowerCase()))
                    .collect(Collectors.toList());
        }

        String selectedCategory = ingredientCategoryComboBox.getValue();
        if (selectedCategory != null && !selectedCategory.isEmpty()) {
            ingredientList = ingredientList.stream()
                    .filter(ingredient -> ingredient.getCategory().getName().equalsIgnoreCase(selectedCategory))
                    .collect(Collectors.toList());
        }

        if(!kcalTextField.getText().isEmpty()) {
            BigDecimal ingredientToKcal = new BigDecimal(kcalTextField.getText());
            ingredientList = ingredientList.stream()
                    .filter(ingredient -> ingredient.getKcal().compareTo(ingredientToKcal) <= 0)
                    .collect(Collectors.toList());
        }

        ObservableList<Ingredient> ingredientObservableList = FXCollections.observableList(ingredientList);
        ingredientTableView.setItems(ingredientObservableList);
    }
}
