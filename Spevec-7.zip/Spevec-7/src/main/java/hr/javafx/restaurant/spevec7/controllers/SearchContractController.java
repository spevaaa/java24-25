package hr.javafx.restaurant.spevec7.controllers;

import hr.javafx.restaurant.spevec7.restaurant.enumeration.ContractType;
import hr.javafx.restaurant.spevec7.restaurant.model.Contract;
import hr.javafx.restaurant.spevec7.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.ContractRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class SearchContractController {
    @FXML
    private TextField salaryTextField;
    @FXML
    private TableView<Contract> contractTableView;
    @FXML
    private TableColumn<Contract, String> contractIdColumn;
    @FXML
    private TableColumn<Contract, String> contractSalaryColumn;
    @FXML
    private TableColumn<Contract, String> contractStartDateColumn;
    @FXML
    private TableColumn<Contract, String> contractEndDateColumn;
    @FXML
    private TableColumn<Contract, String> contractTypeColumn;
    @FXML
    private TextField contractTypeTextField;
    @FXML
    private DatePicker startDateDatePicker;
    @FXML
    private DatePicker endDateDatePicker;


    @FXML
    private TextField addSalaryTextField;
    @FXML
    private ComboBox<ContractType> addContractTypeComboBox;
    @FXML
    private DatePicker addStartDateDatePicker;
    @FXML
    private DatePicker addEndDateDatePicker;

    @FXML
    private CheckBox addActiveContractCheckBox;
    @FXML
    private TableColumn<Contract, String> activeContractColumn;

    private AbstractRepository<Contract> contractRepository = new ContractRepository();

    public void initialize() {
        contractIdColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getId())));

        contractSalaryColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getSalary())));

        contractStartDateColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getStartDate())));

        contractEndDateColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getStartDate())));

        contractTypeColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getContractType().getContractType()));

        addContractTypeComboBox.setItems(FXCollections.observableArrayList(ContractType.values()));
    }

    public void filterContracts() {
        List<Contract> contractList = contractRepository.findAll();

        if (!salaryTextField.getText().isEmpty()) {
            BigDecimal salary = new BigDecimal(salaryTextField.getText());
            contractList = contractList.stream()
                    .filter(contract -> contract.getSalary().compareTo(salary) <= 0)
                    .collect(Collectors.toList());
        }

        if (startDateDatePicker.getValue() != null) {
            contractList = contractList.stream()
                    .filter(contract -> contract.getStartDate() != null && !contract.getStartDate().isBefore(startDateDatePicker.getValue()))
                    .collect(Collectors.toList());
        }

        if (endDateDatePicker.getValue() != null) {
            contractList = contractList.stream()
                    .filter(contract -> contract.getEndDate() != null && !contract.getEndDate().isAfter(endDateDatePicker.getValue()))
                    .collect(Collectors.toList());
        }

        String contractType = contractTypeTextField.getText();
        if (!contractType.isEmpty()) {
            contractList = contractList.stream()
                    .filter(contract -> contract.getContractType().getContractType().toLowerCase().contains(contractType.toLowerCase()))
                    .collect(Collectors.toList());
        }

        String active = addActiveContractCheckBox.isSelected() ? "Yes" : "No";

        ObservableList<Contract> contractObservableList = FXCollections.observableList(contractList);
        contractTableView.setItems(contractObservableList);
    }

    public void addNewContract() {
        String salary = addSalaryTextField.getText().trim();
        if (salary.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setHeaderText(null);
            alert.setContentText("Please enter a valid salary.");
            alert.showAndWait();
            return;
        }

        BigDecimal addedSalary;
        try {
            addedSalary = new BigDecimal(salary);
            if (addedSalary.compareTo(BigDecimal.ZERO) <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Salary");
            alert.setHeaderText(null);
            alert.setContentText("Salary must be a positive numeric value.");
            alert.showAndWait();
            return;
        }

        LocalDate startDate = addStartDateDatePicker.getValue();
        LocalDate endDate = addEndDateDatePicker.getValue();

        if (startDate == null || endDate == null || endDate.isBefore(startDate)) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Invalid Dates");
            alert.setHeaderText(null);
            alert.setContentText("Please select a valid start and end date. End date must be after start date.");
            alert.showAndWait();
            return;
        }


        ContractType contractType = addContractTypeComboBox.getValue();
        if (!contractType.equals("FULL_TIME") && !contractType.equals("PART_TIME")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Contract Type");
            alert.setHeaderText(null);
            alert.setContentText("Enter a valid contract type: FULL_TIME or PART_TIME.");
            alert.showAndWait();
        }
        boolean activeContract = addActiveContractCheckBox.isSelected();


        Contract addedContract = new Contract(addedSalary, startDate, endDate, contractType, activeContract);
        contractRepository.save(addedContract);
        contractTableView.getItems().add(addedContract);

    }
}
