package hr.javafx.restaurant.spevec7.restaurant.repository;

import hr.javafx.restaurant.spevec7.restaurant.model.Category;
import hr.javafx.restaurant.spevec7.restaurant.model.Ingredient;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class IngredientRepository <T extends Ingredient> extends AbstractRepository<T> {
    private static final String INGREDIENTS_FILE_PATH = "dat/ingredients.txt";
    private static final Integer NUMBER_OF_ROWS_PER_INGREDIENT = 5;

    @Override
    public List<T> findAll() {
        List<T> ingredients = new ArrayList<>();
        CategoriesRepository categoriesRepository = new CategoriesRepository();

        try (Stream<String> stream = Files.lines(Path.of(INGREDIENTS_FILE_PATH))) {
            List<String> fileRows = stream.collect(Collectors.toList());

            for (Integer recordNumber = 0; recordNumber < (fileRows.size() / NUMBER_OF_ROWS_PER_INGREDIENT); recordNumber++) {
                Long id = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_INGREDIENT));
                String name = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_INGREDIENT + 1);

                Long categoryId = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_INGREDIENT + 2));
                Category category = categoriesRepository.findById(categoryId);

                BigDecimal kcal= new BigDecimal(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_INGREDIENT + 3));
                String preparationMethod = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_INGREDIENT + 4);

                Ingredient ingredient = new Ingredient(id, name, category, kcal, preparationMethod);
                ingredients.add((T) ingredient);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return ingredients;
    }

    @Override
    public T findById(Long id) {
        return findAll().stream().filter(entity -> entity.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public void save(List<T> entities) {
        try (PrintWriter writer = new PrintWriter(INGREDIENTS_FILE_PATH)) {
            for (T entity : entities) {
                writer.println(entity.getId());
                writer.println(entity.getName());
                writer.println(entity.getCategory().getId());
                writer.println(entity.getKcal());
                writer.println(entity.getPreparationMethod());
            }
            writer.flush();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void save(T entity) {
        List<T> ingredients = findAll();
        if(Optional.ofNullable(entity.getId()).isEmpty()) {
            entity.setId(generateNewId());
        }
        ingredients.add(entity);
        save(ingredients);
    }

    private Long generateNewId() {
        return findAll().stream().map(i -> i.getId())
                .max((i1, i2) -> i1.compareTo(i2)).orElse(0l) + 1;
    }
}
