module hr.javafx.restaurant.spevec7 {
    requires javafx.controls;
    requires javafx.fxml;

    opens hr.javafx.restaurant.spevec7 to javafx.fxml;
    exports hr.javafx.restaurant.spevec7.controllers;
    opens hr.javafx.restaurant.spevec7.controllers to javafx.fxml;
    exports hr.javafx.restaurant.spevec7.main;
    opens hr.javafx.restaurant.spevec7.main to javafx.fxml;
}