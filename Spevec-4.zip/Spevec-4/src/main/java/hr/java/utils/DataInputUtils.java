package hr.java.utils;
import hr.java.restaurant.model.Category;
import hr.java.restaurant.model.Ingredient;
import hr.java.restaurant.model.Meal;
import hr.java.restaurant.model.Restaurant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Služi za unos podataka
 */

public class DataInputUtils {

    private static Logger log = LoggerFactory.getLogger(DataInputUtils.class);

    /**
     * Služi za odabir jednog od unesenih "Category" objekata
     *
     * @param categories polje prethodno unesenih objekata klase "Category"
     * @param scanner objekt klase "Scanner koji omogućava unos podataka
     * @param errorMessage poruka koja se prikazuje prilikom pogresnog unosa
     * @return odabrani objekt klase "Category"
     */

    public static Category getCategory(Category[] categories, Scanner scanner, String errorMessage)
    {
        Integer categoryIndex;
        Boolean isValid;
        Category category = null;
        do {
            try {
                isValid = true;
                categoryIndex = scanner.nextInt();
                category = categories[categoryIndex - 1];
            } catch (InputMismatchException e) {
                log.error(errorMessage);
                isValid = false;
                System.out.println(errorMessage);
                scanner.nextLine();
            } catch (IndexOutOfBoundsException e) {
                log.error(errorMessage);
                isValid = false;
                System.out.println(errorMessage);
                scanner.nextLine();
            }
        } while (!isValid);

        return category;
    }

    public static Restaurant getRestaurant(Restaurant[] restaurants, Scanner scanner, String errorMessage) {
        Integer restaurantIndex;
        Boolean isValid;
        Restaurant restaurant = null;

        do {
            try {
                isValid = true;
                restaurantIndex = scanner.nextInt();
                restaurant = restaurants[restaurantIndex - 1];
            } catch (InputMismatchException e) {
                log.error(errorMessage);
                isValid = false;
                System.out.println(errorMessage);
                scanner.nextLine();
            } catch (IndexOutOfBoundsException e) {
                log.error(errorMessage);
                isValid = false;
                System.out.println(errorMessage);
                scanner.nextLine();
            }
        } while (!isValid);

        return restaurant;
    }

    public static Set<Ingredient> inputIngredients(Scanner scanner, Set<Ingredient> ingredients, int numberOfIngredients, String errorMessage) {
        Set<Ingredient> selectedIngredients = new HashSet<>();
        List<Ingredient> ingredientList = new ArrayList<>(ingredients);

        for (int i = 0; i < ingredientList.size(); i++) {
            System.out.println((i + 1) + ". " + ingredientList.get(i).getName());
        }

        for (int i = 0; i < numberOfIngredients; i++) {
            System.out.print("Choose ingredient " + (i + 1) + ": ");
            int ingredientIndex;
            boolean isValid;

            do {
                isValid = true;
                try {
                    ingredientIndex = scanner.nextInt();
                    scanner.nextLine();
                    if (ingredientIndex < 1 || ingredientIndex > ingredientList.size()) {
                        System.out.println(errorMessage);
                        isValid = false;
                    } else {
                        selectedIngredients.add(ingredientList.get(ingredientIndex - 1));
                    }
                } catch (InputMismatchException e) {
                    System.out.println(errorMessage);
                    isValid = false;
                    scanner.nextLine();
                }
            } while (!isValid);
        }

        return selectedIngredients;
    }


    public static Set<Meal> inputMeals(Scanner scanner, Set<Meal> meals, int numberOfMeals, String errorMessage) {
        Set<Meal> selectedMeals = new HashSet<>();
        List<Meal> mealList = new ArrayList<>(meals);

        for (int i = 0; i < mealList.size(); i++) {
            System.out.println((i + 1) + ". " + mealList.get(i).getName());
        }

        while (selectedMeals.size() < numberOfMeals) {
            System.out.print("Choose meal " + (selectedMeals.size() + 1) + ": ");
            try {
                int mealIndex = scanner.nextInt() - 1;
                scanner.nextLine();
                if (mealIndex < 0 || mealIndex >= mealList.size()) {
                    System.out.println(errorMessage);
                } else {
                    selectedMeals.add(mealList.get(mealIndex));
                }
            } catch (InputMismatchException e) {
                System.out.println(errorMessage);
                scanner.nextLine();
            }
        }

        return selectedMeals;
    }

    public static Set<Meal> inputMealsFromRestaurant(Restaurant restaurant, Scanner scanner, int numberOfMeals, String errorMessage) {
        Set<Meal> selectedMeals = new HashSet<>();
        Set<Meal> availableMeals = restaurant.getMeals();
        List<Meal> mealList = new ArrayList<>(availableMeals);

        for (int i = 0; i < mealList.size(); i++) {
            System.out.println((i + 1) + ". " + mealList.get(i).getName());
        }

        for (int i = 0; i < numberOfMeals; i++) {
            System.out.print("Choose meal " + (i + 1) + ": ");
            int mealIndex;
            boolean isValid;

            do {
                isValid = true;
                try {
                    mealIndex = scanner.nextInt();
                    scanner.nextLine();
                    if (mealIndex < 1 || mealIndex > mealList.size()) {
                        System.out.println(errorMessage);
                        isValid = false;
                    } else {
                        selectedMeals.add(mealList.get(mealIndex - 1)); // Add the selected meal to the set
                        isValid = true;
                    }
                } catch (InputMismatchException e) {
                    log.error(errorMessage);
                    System.out.println(errorMessage);
                    isValid = false;
                    scanner.nextLine();
                }
            } while (!isValid);
        }
        return selectedMeals;
    }
}
