package hr.java.restaurant.model;

import hr.java.restaurant.exception.DuplicateEntityException;
import hr.java.restaurant.exception.NegativOrUnrealPrice;
import hr.java.utils.DuplicateNameCheck;
import hr.java.utils.InputValidator;
import hr.java.utils.Messages;
import hr.java.utils.PriceCheck;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.*;

/**
 * Klasa Waiter koja predstavlja konobare u restoranima.
 * Sadrži podatke o imenu, prezimenu, ugovoru i bonusu za svakog konobara.
 */
public class Waiter extends Person {

    private static Logger log = LoggerFactory.getLogger(Waiter.class);

    private Bonus bonus;

    /**
     * Konstruktor za kreiranje objekta tipa Waiter, koristi builder pattern
     * @param builder
     */
    private Waiter(Builder builder) {
        super(builder.firstName, builder.lastName, builder.contract);
        this.bonus = builder.bonus;
    }

    public Bonus getBonus() {
        return bonus;
    }

    public void setBonus(Bonus bonus) {
        this.bonus = bonus;
    }

    /**
     * Klasa Builder za korištenje builder patterna
     */
    public static class Builder {
        private String firstName;
        private String lastName;
        private Contract contract;
        private Bonus bonus;

        public Builder withFirstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder withLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder withContract(Contract contract) {
            this.contract = contract;
            return this;
        }

        public Builder withBonus(Bonus bonus) {
            this.bonus = bonus;
            return this;
        }

        public Waiter build() {
            return new Waiter(this);
        }
    }

    /**
     * Metoda za upis podataka o konobaru
     * @param waiters - polje konobara u koji se upisuju podaci o konobaru
     * @param scanner - čitanje podataka s tipkovnice
     */
    public static void inputWaiter(Set<Waiter> waiters, Scanner scanner) {
        for (int i = 0; i < waiters.size(); i++)
        {
            Boolean isValid;
            String firstName;
            String lastName;
            do {
                isValid = true;
                System.out.print("Enter " + (i + 1) + ". waiters's first name: ");
                firstName = scanner.nextLine();
                System.out.print("Enter " + (i + 1) + ". waiters's last name: ");
                lastName = scanner.nextLine();
                try {
                    DuplicateNameCheck.checkDuplicateWaiter(firstName, lastName, waiters, i);
                } catch (DuplicateEntityException e) {
                    isValid = false;
                    log.error(e.getMessage());
                    System.out.println(e.getMessage());
                }
            } while (!isValid);

            System.out.println("Enter details for " + (i + 1) + ". waiter's contract:");
            Contract contract = Contract.inputContract(scanner);

            System.out.print("Enter " + (i + 1) + ". waiter's bonus amount: ");
            BigDecimal bonusAmount;

            do {
                isValid = true;
                bonusAmount = InputValidator.validatePositiveBigDecimal(scanner, Messages.INVALID_BONUS_INPUT);
                try {
                    PriceCheck.checkBonus(bonusAmount);
                } catch (NegativOrUnrealPrice e) {
                    isValid = false;
                    log.error(e.getMessage());
                    System.out.println(e.getMessage());
                }
            } while (!isValid);

            Bonus bonus = new Bonus(bonusAmount);

            Waiter waiter = new Waiter.Builder().withFirstName(firstName).withLastName(lastName).withContract(contract).withBonus(bonus).build();
            waiters.add(waiter);
        }
    }

    public static Waiter findBestPaidWaiter(Set<Waiter> waiters) {
        if (waiters == null || waiters.isEmpty()) {
            throw new IllegalArgumentException("The set of waiters cannot be null or empty.");
        }

        Map<Waiter, BigDecimal> waiterPayMap = new HashMap<>();

        Iterator<Waiter> iterator = waiters.iterator();
        while (iterator.hasNext()) {
            Waiter waiter = iterator.next();
            BigDecimal salary = waiter.getContract().getSalary();
            BigDecimal bonus = waiter.getBonus().getAmount();
            BigDecimal totalPay = salary.add(bonus);
            waiterPayMap.put(waiter, totalPay);
        }

        Waiter bestPaidWaiter = null;
        BigDecimal highestPay = BigDecimal.ZERO;

        for (Map.Entry<Waiter, BigDecimal> entry : waiterPayMap.entrySet()) {
            if (entry.getValue().compareTo(highestPay) > 0) {
                highestPay = entry.getValue();
                bestPaidWaiter = entry.getKey();
            }
        }

        return bestPaidWaiter;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Waiter waiter = (Waiter) o;
        return Objects.equals(bonus, waiter.bonus);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(bonus);
    }




}