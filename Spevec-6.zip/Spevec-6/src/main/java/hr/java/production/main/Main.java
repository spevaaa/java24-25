package hr.java.production.main;

import hr.java.restaurant.model.*;
import hr.java.utils.ReadFromFile;
import hr.java.utils.SerializationUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

public class Main {

    public static Logger log = LoggerFactory.getLogger(Main.class.getName());

    /**
     * Ovo je metoda main u klasi Main, pokreće program i traži upise svih podataka za restoran
     *
     * @param args
     */
    public static void main(String[] args) {

        log.info("Starting application...");

        Scanner sc = new Scanner(System.in);

        List<Category> categories = ReadFromFile.readCategories("dat\\categories.txt");
        Set<Ingredient> ingredients = ReadFromFile.readIngredients("dat\\ingredients.txt", categories);
        Set<Meal> meals = ReadFromFile.readMeals("dat\\meals.txt", categories, ingredients);
        Set<Chef> chefs = ReadFromFile.readChefs("dat\\chefs.txt");
        Set<Waiter> waiters = ReadFromFile.readWaiters("dat\\waiters.txt");
        Set<Deliverer> deliverers = ReadFromFile.readDeliverers("dat\\deliverers.txt");
        Set<Restaurant> restaurants = ReadFromFile.readRestaurants("dat\\restaurants.txt", meals, chefs, waiters, deliverers);
        Set<Order> orders = ReadFromFile.readOrders("dat\\orders.txt", restaurants, meals, deliverers);
        Set<Contract> contracts = ReadFromFile.readContracts("dat\\contracts.txt");

        try {
            SerializationUtil.serialize(restaurants, "restaurants.ser");
            SerializationUtil.serialize(orders, "orders.ser");
            SerializationUtil.serialize(contracts, "contracts.ser");

            System.out.println("Objekti su uspješno serijalizirani.");

            Set<Restaurant> deserializedRestaurants = (Set<Restaurant>) SerializationUtil.deserialize("restaurants.ser");
            Set<Order> deserializedOrders = (Set<Order>) SerializationUtil.deserialize("orders.ser");
            Set<Contract> deserializedContracts = (Set<Contract>) SerializationUtil.deserialize("contracts.ser");

            System.out.println("Objekti su uspješno deserijalizirani.");

            System.out.println("Deserijalizirani restorani: " + deserializedRestaurants.size());
            System.out.println("Deserijalizirane narudžbe: " + deserializedOrders.size());
            System.out.println("Deserijalizirani ugovori: " + deserializedContracts.size());

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Došlo je do pogreške prilikom serijalizacije/deserijalizacije: " + e.getMessage());
        }
    }
}