package hr.java.utils;

import hr.java.restaurant.enumeration.ContractType;
import hr.java.restaurant.enumeration.SpiceType;
import hr.java.restaurant.model.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ReadFromFile {

    public static List<Category> readCategories(String fileName) {
        List<Category> categories = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                Long id = Long.parseLong(line.trim());

                String name = br.readLine().trim();

                String description = br.readLine().trim();

                categories.add(new Category.Builder().withId(id).withName(name).withDescription(description).build());
            }
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return categories;
    }

    public static Set<Ingredient> readIngredients(String fileName, List<Category> categories) {
        Set<Ingredient> ingredients = new HashSet<>();

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                Long id = Long.parseLong(line.trim());

                String name = br.readLine().trim();

                int categoryId = Integer.parseInt(br.readLine().trim());
                Category category = categories.stream()
                        .filter(cat -> cat.getId() == categoryId)
                        .findFirst()
                        .orElseThrow(() -> new IllegalArgumentException("Category with ID " + categoryId + " not found."));

                BigDecimal kcal = new BigDecimal(br.readLine().trim());

                String preparationMethod = br.readLine().trim();

                Ingredient ingredient = new Ingredient(id, name, category, kcal, preparationMethod);

                if (!ingredients.add(ingredient)) {
                    System.out.println("Duplicate ingredient with ID " + id + " was ignored.");
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }

        return ingredients;
    }

    public static Set<Meal> readMeals(String fileName, List<Category> categories, Set<Ingredient> ingredients) {
        Set<Meal> meals = new HashSet<>();

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                Long id = Long.parseLong(line.trim());

                String name = br.readLine().trim();

                int categoryId = Integer.parseInt(br.readLine().trim());
                Category category = categories.stream()
                        .filter(cat -> cat.getId() == categoryId)
                        .findFirst()
                        .orElseThrow(() -> new IllegalArgumentException("Category with ID " + categoryId + " not found."));

                Set<Ingredient> mealIngredients = new HashSet<>();
                String[] ingredientIds = br.readLine().trim().split(",");
                for (String idStr : ingredientIds) {
                    Long ingredientId = Long.parseLong(idStr.trim());
                    Ingredient ingredient = ingredients.stream()
                            .filter(ing -> ing.getId().equals(ingredientId))
                            .findFirst()
                            .orElseThrow(() -> new IllegalArgumentException("Ingredient with ID " + ingredientId + " not found."));
                    mealIngredients.add(ingredient);
                }

                BigDecimal price = new BigDecimal(br.readLine().trim());

                Integer calories = Integer.parseInt(br.readLine().trim());

                String spiceName = br.readLine().trim();
                SpiceType spice = SpiceType.valueOf(spiceName.toUpperCase());
                Set<SpiceType> spices = new HashSet<>();
                spices.add(spice);

                Meal meal = new Meal(id, name, category, mealIngredients, price, calories, spices);

                meals.add(meal);
            }
        } catch (IOException | IllegalArgumentException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }

        return meals;
    }

    public static Set<Chef> readChefs(String fileName) {
        Set<Chef> chefs = new HashSet<>();

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String firstName = line.trim();

                String lastName = br.readLine().trim();

                BigDecimal salary = new BigDecimal(br.readLine().trim());

                LocalDate startDate = LocalDate.parse(br.readLine().trim());
                LocalDate endDate = LocalDate.parse(br.readLine().trim());

                String employmentTypeStr = br.readLine().trim();
                ContractType employmentType = ContractType.valueOf(employmentTypeStr.toUpperCase());

                BigDecimal bonusAmount = new BigDecimal(br.readLine().trim());

                Contract contract = new Contract(salary, startDate, endDate, employmentType);
                Bonus bonus = new Bonus(bonusAmount);

                Chef chef = new Chef.Builder().withFirstName(firstName)
                        .withLastName(lastName)
                        .withContract(contract)
                        .withBonus(bonus).build();

                chefs.add(chef);
            }
        } catch (IOException | IllegalArgumentException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }

        return chefs;
    }

    public static Set<Waiter> readWaiters(String fileName) {
        Set<Waiter> waiters = new HashSet<>();

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String firstName = line.trim();

                String lastName = br.readLine().trim();

                BigDecimal salary = new BigDecimal(br.readLine().trim());

                LocalDate startDate = LocalDate.parse(br.readLine().trim());
                LocalDate endDate = LocalDate.parse(br.readLine().trim());

                String employmentTypeStr = br.readLine().trim();
                ContractType employmentType = ContractType.valueOf(employmentTypeStr.toUpperCase());

                BigDecimal bonusAmount = new BigDecimal(br.readLine().trim());

                Contract contract = new Contract(salary, startDate, endDate, employmentType);
                Bonus bonus = new Bonus(bonusAmount);

                Waiter waiter = new Waiter.Builder().withFirstName(firstName)
                        .withLastName(lastName)
                        .withContract(contract)
                        .withBonus(bonus).build();

                waiters.add(waiter);
            }
        } catch (IOException | IllegalArgumentException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }

        return waiters;
    }

    public static Set<Deliverer> readDeliverers(String fileName) {
        Set<Deliverer> deliverers = new HashSet<>();

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String firstName = line.trim();

                String lastName = br.readLine().trim();

                BigDecimal salary = new BigDecimal(br.readLine().trim());

                LocalDate startDate = LocalDate.parse(br.readLine().trim());
                LocalDate endDate = LocalDate.parse(br.readLine().trim());

                String employmentTypeStr = br.readLine().trim();
                ContractType employmentType = ContractType.valueOf(employmentTypeStr.toUpperCase());

                BigDecimal bonusAmount = new BigDecimal(br.readLine().trim());

                Contract contract = new Contract(salary, startDate, endDate, employmentType);
                Bonus bonus = new Bonus(bonusAmount);

                Deliverer deliverer = new Deliverer.Builder().withFirstName(firstName)
                        .withLastName(lastName)
                        .withContract(contract)
                        .withBonus(bonus).build();

                deliverers.add(deliverer);
            }
        } catch (IOException | IllegalArgumentException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }

        return deliverers;
    }

    public static Set<Restaurant> readRestaurants(String restaurantFile, Set<Meal> meals, Set<Chef> chefs, Set<Waiter> waiters, Set<Deliverer> deliverers) {
        Set<Restaurant> restaurants = new HashSet<>();

        try (BufferedReader br = new BufferedReader(new FileReader(restaurantFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                Long restaurantId = Long.valueOf(line.trim());
                String restaurantName = br.readLine().trim();
                String addressLine = br.readLine().trim();
                String[] addressParts = addressLine.split(", ");
                Address address = new Address.Builder().withId(restaurantId)
                        .withStreet(addressParts[0])
                        .withHouseNumber(addressParts[1])
                        .withCity(addressParts[2])
                        .withPostalCode(addressParts[3]).build();

                Long mealId = Long.valueOf(br.readLine().trim());
                Integer chefIndex = Integer.valueOf(br.readLine().trim());
                Integer waiterIndex = Integer.valueOf(br.readLine().trim());
                Integer delivererIndex = Integer.valueOf(br.readLine().trim());

                Meal meal = getMealById(meals, mealId);
                Chef chef = getEmployeeByIndex(chefs, chefIndex);
                Waiter waiter = getEmployeeByIndex(waiters, waiterIndex);
                Deliverer deliverer = getEmployeeByIndex(deliverers, delivererIndex);

                Set<Meal> mealSet = new HashSet<>();
                mealSet.add(meal);

                Set<Chef> chefSet = new HashSet<>();
                chefSet.add(chef);

                Set<Waiter> waiterSet = new HashSet<>();
                waiterSet.add(waiter);

                Set<Deliverer> delivererSet = new HashSet<>();
                delivererSet.add(deliverer);

                Restaurant restaurant = new Restaurant(restaurantId, restaurantName, address, mealSet, chefSet, waiterSet, delivererSet);
                restaurants.add(restaurant);
            }
        } catch (IOException e) {
            System.err.println("Error reading restaurants file: " + e.getMessage());
        }

        return restaurants;
    }

    private static Meal getMealById(Set<Meal> meals, Long mealId) {
        return meals.stream()
                .filter(meal -> meal.getId().equals(mealId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Meal with ID " + mealId + " not found"));
    }

    private static <T> T getEmployeeByIndex(Set<T> employees, Integer index) {
        return employees.stream()
                .skip(index - 1)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Employee at index " + index + " not found"));
    }

    public static Set<Order> readOrders(String ordersFile, Set<Restaurant> restaurants, Set<Meal> meals, Set<Deliverer> deliverers) {
        Set<Order> orders = new HashSet<>();

        try (BufferedReader br = new BufferedReader(new FileReader(ordersFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                Long orderId = Long.valueOf(line.trim());
                Long restaurantId = Long.valueOf(br.readLine().trim());
                Long mealId = Long.valueOf(br.readLine().trim());
                Integer delivererId = Integer.valueOf(br.readLine().trim());
                String deliveryDateString = br.readLine().trim();

                Restaurant restaurant = getRestaurantById(restaurants, restaurantId);
                Meal meal = getMealById(meals, mealId);
                Deliverer deliverer = getEmployeeByIndex(deliverers, delivererId);

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                LocalDateTime deliveryDateAndTime = LocalDateTime.parse(deliveryDateString, formatter);

                Set<Meal> mealSet = new HashSet<>();
                mealSet.add(meal);

                Order order = new Order(orderId, restaurant, mealSet, deliverer, deliveryDateAndTime);
                orders.add(order);
            }
        } catch (IOException e) {
            System.err.println("Error reading orders file: " + e.getMessage());
        }

        return orders;
    }

    private static Restaurant getRestaurantById(Set<Restaurant> restaurants, Long restaurantId) {
        return restaurants.stream()
                .filter(r -> r.getId().equals(restaurantId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Restaurant not found"));
    }

    public static Set<Contract> readContracts(String filename) {
        Set<Contract> contracts = new HashSet<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                BigDecimal salary = new BigDecimal(line.trim());

                line = br.readLine();
                LocalDate startDate = LocalDate.parse(line.trim());

                line = br.readLine();
                LocalDate endDate = LocalDate.parse(line.trim());

                line = br.readLine();
                ContractType employmentType = ContractType.valueOf(line.trim().toUpperCase());

                Contract contract = new Contract(salary, startDate, endDate, employmentType);

                contracts.add(contract);
            }
        } catch (IOException e) {
            System.err.println("Error reading contracts file: " + e.getMessage());
        }

        return contracts;
    }
}
