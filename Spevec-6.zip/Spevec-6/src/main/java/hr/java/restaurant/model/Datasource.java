package hr.java.restaurant.model;

import java.util.List;

public interface Datasource <T, S>{

    public void spremiPodatke(List<T> data);

    public S dohvatiPodatke();

    }