package hr.java.restaurant.sort;

import hr.java.restaurant.model.Meal;
import hr.java.restaurant.model.Restaurant;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class NumberOfMealsSort implements Comparator<Meal> {

    private final Map<Meal, List<Restaurant>> mealsInRestaurants;

    public NumberOfMealsSort(Map<Meal, List<Restaurant>> mealToRestaurants) {
        this.mealsInRestaurants = mealToRestaurants;
    }

    @Override
    public int compare(Meal m1, Meal m2) {
        int size1 = mealsInRestaurants.get(m1).size();
        int size2 = mealsInRestaurants.get(m2).size();
        return Integer.compare(size2, size1);
    }
}
