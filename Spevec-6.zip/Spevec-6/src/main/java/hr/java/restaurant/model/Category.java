package hr.java.restaurant.model;

import hr.java.restaurant.exception.DuplicateEntityException;
import hr.java.utils.DuplicateNameCheck;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.Scanner;

/**
 * Klasa Category koja predstavlja kategorije sastojaka i jela
 * Sadrži naziv i opis kategorije.
 */
public class Category extends Entity implements Serializable {

    private static final long serialVersionUID = 1L;
    private static Logger log = LoggerFactory.getLogger(Category.class);

    private String name;
    private String description;

    /**
     * Konstruktor za objekte tipa Category, koristi se builder pattern
     * @param builder
     */
    private Category(Builder builder) {
        super(builder.id);
        this.name = builder.name;
        this.description = builder.description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Klasa Builder za korištenje builder patterna
     */
    public static class Builder {
        private Long id;
        private String name;
        private String description;

        public Builder withId(Long id) {
            this.id = id;
            return this;
        }

        public Builder withName(String name) {
            this.name = name;
            return this;
        }

        public Builder withDescription(String description) {
            this.description = description;
            return this;
        }

        public Category build() {
            return new Category(this);
        }
    }

    /**
     * Metoda za upis kategorija, provjerava postoji li kategorija s istim imenom.
     * Duplikati imena kategorija ne smiju postojati.
     * @param categories - prima polje kategorija u koji zapisuje unesene kategorije.
     * @param scanner - čitanje s tipkovnice
     */
    public static void inputCategory(Category[] categories, Scanner scanner) {
        for (int i = 0; i < categories.length; i++)
        {
            Boolean isValid;
            String name;
            do {
                isValid = true;
                System.out.print("Enter the name of the " + (i + 1) + ". category: ");
                name = scanner.nextLine();
                try {
                    DuplicateNameCheck.checkDuplicateCategory(name, categories, i);
                } catch (DuplicateEntityException e) {
                    isValid = false;
                    log.error(e.getMessage());
                    System.out.println(e.getMessage());
                }
            } while (!isValid);

            System.out.print("Enter the description of the " + (i+1) + "." + " category: ");
            String description = scanner.nextLine();
            categories[i] = new Category.Builder().withId((long) (i + 1)).withName(name).withDescription(description).build();
        }
    }

}
