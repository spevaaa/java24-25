package hr.java.restaurant.model;
import hr.java.utils.DataEmployeeInputUtils;
import hr.java.utils.DataInputUtils;
import hr.java.utils.InputValidator;
import hr.java.utils.Messages;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import java.util.Set;

/**
 * Klasa Order koja predstavlja narudžbe.
 * Sadrži restoran iz kojeg je narudžba, polje jela koja su u narudžbi,
 * dostavljača koji dostavlja te datum i vrijeme narudžbe
 */
public class Order extends Entity implements Serializable {

    private static final long serialVersionUID = 1L;

    private Restaurant restaurant;
    private Set<Meal> meals;
    private Deliverer deliverer;
    private LocalDateTime deliveryDateAndTime;

    /**
     * Konstruktor za kreiranje objekta tipa Order
     * @param id - predstavlja ID narudžbe
     * @param restaurant - predstavlja restoran iz kojeg dolazi narudžba
     * @param meals - predstavlja jela u narudžbi
     * @param deliverer - predstavlja dostavljača koji dostavlja
     * @param deliveryDateAndTime - predstavlja datum i vrijeme narudžbe
     */
    public Order(Long id, Restaurant restaurant, Set<Meal> meals, Deliverer deliverer, LocalDateTime deliveryDateAndTime) {
        super(id);
        this.restaurant = restaurant;
        this.meals = meals;
        this.deliverer = deliverer;
        this.deliveryDateAndTime = deliveryDateAndTime;
    }
    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public Set<Meal> getMeals() {
        return meals;
    }

    public void setMeals(Set<Meal> meals) {
        this.meals = meals;
    }

    public Deliverer getDeliverer() {
        return deliverer;
    }

    public void setDeliverer(Deliverer deliverer) {
        this.deliverer = deliverer;
    }

    public LocalDateTime getDeliveryDateAndTime() {
        return deliveryDateAndTime;
    }

    public void setDeliveryDateAndTime(LocalDateTime deliveryDateAndTime) {
        this.deliveryDateAndTime = deliveryDateAndTime;
    }

    /**
     * Metoda za upis podataka o narudžbi
     * @param orders - polje narudžbi u koje se upisuju podaci o narudžbi
     * @param restaurants - polje za odabir restorana iz kojeg je narudžba
     * @param meals - polje za odabir jela za narudžbu
     * @param chefs - polje kuhara za odabir tko će skuhati jela
     * @param deliverers - polje dostavljača za odabir tko će dostaviti
     * @param scanner - čitanje podataka s tipkovnice
     */
    public static void inputOrder(Order[] orders, Restaurant[] restaurants, Set<Meal> meals, Set<Chef> chefs, Set<Deliverer> deliverers, Scanner scanner) {
        for (int i = 0; i < orders.length; i++) {
            System.out.print("Choose a restaurant for your " + (i + 1) + ". order (index 1,2,3): \n");
            for (int j = 0; j < restaurants.length; j++) {
                System.out.print((j + 1) + ". " + restaurants[j].getName() + "\n");
            }
            Restaurant selectedRestaurant = DataInputUtils.getRestaurant(restaurants, scanner, Messages.INVALID_RESTAURANT_INDEX_INPUT);

            System.out.print("Enter the number of meals in the order: ");
            int numberOfMeals = InputValidator.validatePositiveInteger(scanner, Messages.INVALID_NUMBER_OF_MEALS_INPUT);

            System.out.println("Available meals in " + selectedRestaurant.getName() + ":");
            Set<Meal> selectedMeals = DataInputUtils.inputMealsFromRestaurant(selectedRestaurant, scanner, numberOfMeals, Messages.INVALID_INTEGER_INDEX_MEAL_INPUT);

            System.out.print("Choose a deliverer for the order (index 1,2,3): \n");
            int index = 1;
            for (Deliverer deliverer : selectedRestaurant.getDeliverers()) {
                System.out.println(index + ". " + deliverer.getFirstName() + " " + deliverer.getLastName());
                index++;
            }
            Deliverer selectedDeliverer = DataEmployeeInputUtils.inputDelivererFromRestaurant(selectedRestaurant, scanner, Messages.INVALID_DELIVERER_INDEX_INPUT);

            System.out.print("Enter the date and time of the order (format: dd-MM-yyyy HH:mm): ");
            String dateTimeInput = scanner.nextLine();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
            LocalDateTime deliveryDateAndTime = null;

            boolean validDateTime = false;
            while (!validDateTime) {
                try {
                    deliveryDateAndTime = LocalDateTime.parse(dateTimeInput, formatter);
                    validDateTime = true;
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid date and time format. Please enter the date in the correct format: dd-MM-yyyy HH:mm.");
                    dateTimeInput = scanner.nextLine();
                }
            }

            orders[i] = new Order(Long.valueOf(i + 1), selectedRestaurant, selectedMeals, selectedDeliverer, deliveryDateAndTime);
        }
    }

    public static Order[] findMostExpensiveOrderRestaurants(Order[] orders) {
        Order[] mostExpensiveOrders = new Order[orders.length];
        Integer counterOfMostExpensiveOrders = 0;

        BigDecimal mostExpensive = BigDecimal.valueOf(0);

        Order[] mostExpensiveOrdersReturn = new Order[counterOfMostExpensiveOrders];
        for (int i = 0; i < counterOfMostExpensiveOrders; i++) {
            mostExpensiveOrdersReturn[i] = mostExpensiveOrders[i];
        }
        return mostExpensiveOrdersReturn;
    }

    public static Deliverer[] findDelivererWithMostDeliveries (Order[] orders)
    {
        int maxDeliveries = 0;
        int[] deliveryCounts = new int[orders.length];
        Deliverer[] deliverers = new Deliverer[orders.length];
        int delivererCount = 0;

        for (int i = 0; i < orders.length; i++) {
            Deliverer currentDeliverer = orders[i].getDeliverer();
            boolean found = false;
            int delivererIndex = -1;

            for (int j = 0; j < delivererCount; j++) {
                if (deliverers[j].equals(currentDeliverer)) {
                    found = true;
                    delivererIndex = j;
                    break;
                }
            }
            if (!found) {
                deliverers[delivererCount] = currentDeliverer;
                deliveryCounts[delivererCount] = 1;
                delivererCount++;
            } else {
                deliveryCounts[delivererIndex]++;
            }
        }
        for (int i = 0; i < delivererCount; i++) {
            if (deliveryCounts[i] > maxDeliveries) {
                maxDeliveries = deliveryCounts[i];
            }
        }
        int resultCount = 0;
        for (int i = 0; i < delivererCount; i++) {
            if (deliveryCounts[i] == maxDeliveries) {
                resultCount++;
            }
        }
        Deliverer[] topDeliverers = new Deliverer[resultCount];
        int index = 0;
        for (int i = 0; i < delivererCount; i++) {
            if (deliveryCounts[i] == maxDeliveries) {
                topDeliverers[index] = deliverers[i];
                index++;
            }
        }
        return topDeliverers;
    }
}