package hr.java.restaurant.model;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class DostavljaciDatotekaDatasource implements Datasource<Deliverer, Set<Deliverer>>{
    private String path;

    public DostavljaciDatotekaDatasource(String path) {
        this.path = path;
    }

    public List<Deliverer> ucitajDostavljace() throws IOException {
        List<Deliverer> dostavljaci = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String linija;
            while ((linija = reader.readLine()) != null) {
                dostavljaci.add(new Deliverer.Builder().withFirstName(linija).withLastName(linija).build());
            }
        }
        return dostavljaci;
    }

    public void sacuvajDostavljace(List<Deliverer> dostavljaci) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            for (Deliverer dostavljac : dostavljaci) {
                writer.write(dostavljac.toString());
                writer.newLine();
            }
        }
    }

    @Override
    public void spremiPodatke(List<Deliverer> data) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
            oos.writeObject(data);
        } catch (IOException e) {
            throw new RuntimeException("Greška pri spremanju podataka u datoteku.", e);
        }
    }

    @Override
    public Set<Deliverer> dohvatiPodatke() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(path))) {
            Set<Deliverer> data = (Set<Deliverer>) ois.readObject();
            return data;
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException("Greška pri dohvaćanju podataka iz datoteke.", e);
        }
    }

    public void grupirajDostavljacePoDatumu() throws IOException {
        List<Deliverer> dostavljaci = ucitajDostavljace();
        Map<String, List<Deliverer>> groupedByDate = new HashMap<>();

        for (Deliverer dostavljac : dostavljaci) {
            String deliveryDate = dostavljac.getDeliveryDate();
            groupedByDate.putIfAbsent(deliveryDate, new ArrayList<>());
            groupedByDate.get(deliveryDate).add(dostavljac);
        }

        for (String date : groupedByDate.keySet()) {
            Path directoryPath = Paths.get(path, date);
            if (!Files.exists(directoryPath)) {
                Files.createDirectories(directoryPath);
            }

            List<Deliverer> deliverersForDate = groupedByDate.get(date);
            Path filePath = directoryPath.resolve("dostavljaci.txt");
            try (BufferedWriter writer = Files.newBufferedWriter(filePath)) {
                for (Deliverer deliverer : deliverersForDate) {
                    writer.write(deliverer.toString());
                    writer.newLine();
                }
            }
        }
    }
}
