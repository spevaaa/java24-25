package hr.java.restaurant.generics;

public class WorkAssignment<S, T> {
    private S worker;
    private T task;

    public WorkAssignment(S worker, T task) {
        this.worker = worker;
        this.task = task;
    }

    public S getWorker() {
        return worker;
    }

    public void setWorker(S worker) {
        this.worker = worker;
    }

    public T getTask() {
        return task;
    }

    public void setTask(T task) {
        this.task = task;
    }
}
