package hr.java.restaurant.exception;

public class InvalidBonusAmountException extends RuntimeException {
    private int amount;

    public InvalidBonusAmountException(int amount) {
        super("Invalid bonus amount: " + amount);
        this.amount = amount;
    }

}