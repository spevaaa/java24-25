package hr.javafx.restaurant.spevec7.controllers;

import hr.javafx.restaurant.spevec7.main.Main;
import hr.javafx.restaurant.spevec7.restaurant.enumeration.ContractType;
import hr.javafx.restaurant.spevec7.restaurant.model.Bonus;
import hr.javafx.restaurant.spevec7.restaurant.model.Category;
import hr.javafx.restaurant.spevec7.restaurant.model.Chef;
import hr.javafx.restaurant.spevec7.restaurant.model.Contract;
import hr.javafx.restaurant.spevec7.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.CategoriesRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.ChefRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.ContractRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class AddChefController {
    @FXML
    private TextField addChefFirstNameTextField;
    @FXML
    private TextField addChefLastNameTextField;
    @FXML
    private ComboBox<Long> contractIdComboBox;
    @FXML
    private TextField addChefBonusTextField;

    private AbstractRepository<Chef> chefRepository = new ChefRepository<>();

    private AbstractRepository<Contract> contractRepository = new ContractRepository<>();
    private List<Contract> contractList = contractRepository.findAll();
    private ObservableList<Long> contractIdObservableList = FXCollections.observableArrayList(contractList.stream().map(Contract::getId).collect(Collectors.toList()));

    public void initialize() {
        contractIdComboBox.setItems(contractIdObservableList);
    }

    public void addChef() {
        String firstName = addChefFirstNameTextField.getText();
        String lastName = addChefLastNameTextField.getText();

        Long contractID = contractIdComboBox.getValue();
        Contract contract = contractList.stream().filter(c -> c.getId().equals(contractID)).findFirst().get();

        Bonus bonus = new Bonus(new BigDecimal(addChefBonusTextField.getText()));

        Chef chef = new Chef(firstName, lastName, contract, bonus);

        chefRepository.save(chef);

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec7/showChefs.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
