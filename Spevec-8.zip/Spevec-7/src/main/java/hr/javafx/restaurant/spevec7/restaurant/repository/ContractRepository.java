package hr.javafx.restaurant.spevec7.restaurant.repository;

import hr.javafx.restaurant.spevec7.restaurant.enumeration.ContractType;
import hr.javafx.restaurant.spevec7.restaurant.model.Contract;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ContractRepository <T extends Contract> extends AbstractRepository<T> {
    private static final String CONTRACTS_FILE_PATH = "dat/contracts.txt";
    private static final Integer NUMBER_OF_ROWS_PER_CONTRACT = 5;

    @Override
    public List<T> findAll() {
        List<T> contracts = new ArrayList<>();

        try (Stream<String> stream = Files.lines(Path.of(CONTRACTS_FILE_PATH))) {
            List<String> fileRows = stream.collect(Collectors.toList());

            for (Integer recordNumber = 0; recordNumber < (fileRows.size() / NUMBER_OF_ROWS_PER_CONTRACT); recordNumber++) {
                Long id = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_CONTRACT));
                BigDecimal salary = new BigDecimal(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_CONTRACT + 1));

                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                LocalDate startDate = LocalDate.parse(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_CONTRACT + 2), dateTimeFormatter);
                LocalDate endDate = LocalDate.parse(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_CONTRACT + 3), dateTimeFormatter);

                String contractTypeString = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_CONTRACT + 4);
                ContractType contractType = ContractType.valueOf(contractTypeString);

                Contract contract = new Contract(id, salary, startDate, endDate, contractType);
                contracts.add((T) contract);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return contracts;
    }

    @Override
    public T findById(Long id) {
        return findAll().stream().filter(entity -> entity.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public void save(List<T> entities) {
        try (PrintWriter writer = new PrintWriter(CONTRACTS_FILE_PATH)) {
            for (T entity : entities) {
                writer.println(entity.getId());
                writer.println(entity.getSalary());
                writer.println(entity.getStartDate());
                writer.println(entity.getEndDate());
                writer.println(entity.getContractType());
            }
            writer.flush();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void save(T entity) {
        List<T> contracts = findAll();
        if(Optional.ofNullable(entity.getId()).isEmpty()) {
            entity.setId(generateNewId());
        }
        contracts.add(entity);
        save(contracts);
    }

    private Long generateNewId() {
        return findAll().stream().map(i -> i.getId())
                .max((i1, i2) -> i1.compareTo(i2)).orElse(0l) + 1;
    }
}
