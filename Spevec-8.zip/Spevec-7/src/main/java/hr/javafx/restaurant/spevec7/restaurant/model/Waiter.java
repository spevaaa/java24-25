package hr.javafx.restaurant.spevec7.restaurant.model;

import java.util.Objects;

public class Waiter extends Person {
    private Bonus bonus;

    public Waiter(Long id, String firstName, String lastName, Contract contract, Bonus bonus) {
        super(id, firstName, lastName, contract);
        this.bonus = bonus;
    }

    public Waiter(String firstName, String lastName, Contract contract, Bonus bonus) {
        super(firstName, lastName, contract);
        this.bonus = bonus;
    }

    public Bonus getBonus() {
        return bonus;
    }

    public void setBonus(Bonus bonus) {
        this.bonus = bonus;
    }

    public static class Builder {
        private String firstName;
        private String lastName;
        private Contract contract;
        private Bonus bonus;

        public Builder withFirstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder withLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder withContract(Contract contract) {
            this.contract = contract;
            return this;
        }

        public Builder withBonus(Bonus bonus) {
            this.bonus = bonus;
            return this;
        }

        public Waiter build() {
            Waiter waiter = new Waiter();

            waiter.setFirstName(this.firstName);
            waiter.setLastName(this.lastName);
            waiter.setContract(this.contract);
            waiter.setBonus(this.bonus);

            return waiter;
        }
    }

    private Waiter() {}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Waiter waiter = (Waiter) o;
        return Objects.equals(getFirstName(), waiter.getFirstName()) &&
                Objects.equals(getLastName(), waiter.getLastName()) &&
                Objects.equals(getContract(), waiter.getContract()) &&
                Objects.equals(bonus, waiter.bonus);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFirstName(), getLastName(), getContract(), bonus);
    }

}
