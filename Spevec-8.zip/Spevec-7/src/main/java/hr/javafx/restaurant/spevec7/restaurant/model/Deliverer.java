package hr.javafx.restaurant.spevec7.restaurant.model;

import java.util.Objects;

public class Deliverer extends Person {

    private Bonus bonus;

    public Deliverer(Long id, String firstName, String lastName, Contract contract, Bonus bonus) {
        super(id, firstName, lastName, contract);
        this.bonus = bonus;
    }

    public Deliverer(String firstName, String lastName, Contract contract, Bonus bonus) {
        super(firstName, lastName, contract);
        this.bonus = bonus;
    }

    public Bonus getBonus() {
        return bonus;
    }

    public void setBonus(Bonus bonus) {
        this.bonus = bonus;
    }

    public static class Builder {
        private String firstName;
        private String lastName;
        private Contract contract;
        private Bonus bonus;

        public Builder withFirstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder withLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder withContract(Contract contract) {
            this.contract = contract;
            return this;
        }

        public Builder withBonus(Bonus bonus) {
            this.bonus = bonus;
            return this;
        }

        public Deliverer build() {
            Deliverer deliverer = new Deliverer();

            deliverer.setFirstName(this.firstName);
            deliverer.setLastName(this.lastName);
            deliverer.setContract(this.contract);
            deliverer.setBonus(this.bonus);

            return deliverer;
        }
    }

    private Deliverer() {}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Deliverer deliverer = (Deliverer) o;
        return Objects.equals(getFirstName(), deliverer.getFirstName()) &&
                Objects.equals(getLastName(), deliverer.getLastName()) &&
                Objects.equals(getContract(), deliverer.getContract()) &&
                Objects.equals(bonus, deliverer.bonus);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFirstName(), getLastName(), getContract(), bonus);
    }

}
