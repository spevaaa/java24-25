package hr.javafx.restaurant.spevec7.controllers;

import hr.javafx.restaurant.spevec7.main.Main;
import hr.javafx.restaurant.spevec7.restaurant.model.Bonus;
import hr.javafx.restaurant.spevec7.restaurant.model.Chef;
import hr.javafx.restaurant.spevec7.restaurant.model.Contract;
import hr.javafx.restaurant.spevec7.restaurant.model.Waiter;
import hr.javafx.restaurant.spevec7.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.ChefRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.ContractRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.WaiterRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

public class AddWaiterController {
    @FXML
    private TextField addWaiterFirstNameTextField;
    @FXML
    private TextField addWaiterLastNameTextField;
    @FXML
    private ComboBox<Long> contractIdComboBox;
    @FXML
    private TextField addWaiterBonusTextField;

    private AbstractRepository<Waiter> waiterRepository = new WaiterRepository<>();

    private AbstractRepository<Contract> contractRepository = new ContractRepository<>();
    private List<Contract> contractList = contractRepository.findAll();
    private ObservableList<Long> contractIdObservableList = FXCollections.observableArrayList(contractList.stream().map(Contract::getId).collect(Collectors.toList()));

    public void initialize() {
        contractIdComboBox.setItems(contractIdObservableList);
    }

    public void addWaiter() {
        String firstName = addWaiterFirstNameTextField.getText();
        String lastName = addWaiterLastNameTextField.getText();

        Long contractID = contractIdComboBox.getValue();
        Contract contract = contractList.stream().filter(c -> c.getId().equals(contractID)).findFirst().get();

        Bonus bonus = new Bonus(new BigDecimal(addWaiterBonusTextField.getText()));

        Waiter waiter = new Waiter(firstName, lastName, contract, bonus);

        waiterRepository.save(waiter);

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec7/showChefs.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
