package hr.javafx.restaurant.spevec7.restaurant.model;

import hr.javafx.restaurant.spevec7.restaurant.enumeration.ContractType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DataHolder {
    public static String contractName = "";
    public static BigDecimal contractSalary = BigDecimal.ZERO;
    public static ContractType contractType = null;
    public static LocalDate contractStartDate = null;
    public static LocalDate contractEndDate = null;
    public static List<String> files = new ArrayList<>();
}
