package hr.javafx.restaurant.spevec7.restaurant.repository;

import hr.javafx.restaurant.spevec7.restaurant.model.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RestaurantRepository <T extends Restaurant> extends AbstractRepository<T> {
    private static final String RESTAURANTS_FILE_PATH = "dat/restaurants.txt";
    private static final Integer NUMBER_OF_ROWS_PER_RESTAURANT = 7;

    @Override
    public List<T> findAll() {
        List<T> restaurants = new ArrayList<>();
        MealRepository mealRepository = new MealRepository();
        AddressRepository addressRepository = new AddressRepository();
        ChefRepository chefRepository = new ChefRepository();
        WaiterRepository waiterRepository = new WaiterRepository();
        DelivererRepository delivererRepository = new DelivererRepository();

        try (Stream<String> stream = Files.lines(Path.of(RESTAURANTS_FILE_PATH))) {
            List<String> fileRows = stream.collect(Collectors.toList());

            for (Integer recordNumber = 0; recordNumber < (fileRows.size() / NUMBER_OF_ROWS_PER_RESTAURANT); recordNumber++) {
                Long id = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_RESTAURANT));
                String name = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_RESTAURANT + 1);

                Long addressId = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_RESTAURANT + 2));
                Address address = addressRepository.findById(addressId);

                String mealsIds = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_RESTAURANT + 3);
                Set<Meal> meals = Arrays.stream(mealsIds.split(","))
                        .map(idString -> Long.parseLong(idString))
                        .map(idLong -> mealRepository.findById(idLong))
                        .collect(Collectors.toSet());

                String chefsIds = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_RESTAURANT + 4);
                Set<Chef> chefs = Arrays.stream(chefsIds.split(","))
                        .map(idString -> Long.parseLong(idString))
                        .map(idLong -> chefRepository.findById(idLong))
                        .collect(Collectors.toSet());

                String waitersIds = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_RESTAURANT + 5);
                Set<Waiter> waiters = Arrays.stream(waitersIds.split(","))
                        .map(idString -> Long.parseLong(idString))
                        .map(idLong -> waiterRepository.findById(idLong))
                        .collect(Collectors.toSet());

                String deliverersIds = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_RESTAURANT + 6);
                Set<Deliverer> deliverers = Arrays.stream(deliverersIds.split(","))
                        .map(idString -> Long.parseLong(idString))
                        .map(idLong -> delivererRepository.findById(idLong))
                        .collect(Collectors.toSet());

                Restaurant restaurant=new Restaurant(id, name, address, meals, chefs, waiters, deliverers);
                restaurants.add((T) restaurant);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return restaurants;
    }

    @Override
    public T findById(Long id) {
        return findAll().stream().filter(entity -> entity.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public void save(List<T> entities) {
        try (PrintWriter writer = new PrintWriter(RESTAURANTS_FILE_PATH)) {
            for (T entity : entities) {
                writer.println(entity.getId());
                writer.println(entity.getName());
                writer.println(entity.getAddress().getId());

                StringBuilder mealsBuilder = new StringBuilder();
                for(Meal meal : entity.getMeals()) {
                    mealsBuilder = mealsBuilder.append(meal.getId()).append(",");
                }
                writer.println(mealsBuilder);

                StringBuilder chefsBuilder = new StringBuilder();
                for(Chef chef : entity.getChefs()) {
                    chefsBuilder = chefsBuilder.append(chef.getId()).append(",");
                }
                writer.println(chefsBuilder);

                StringBuilder waitersBuilder = new StringBuilder();
                for(Waiter waiter : entity.getWaiters()) {
                    waitersBuilder = waitersBuilder.append(waiter.getId()).append(",");
                }
                writer.println(waitersBuilder);

                StringBuilder deliverersBuilder = new StringBuilder();
                for(Deliverer deliverer : entity.getDeliverers()) {
                    deliverersBuilder = deliverersBuilder.append(deliverer.getId()).append(",");
                }
                writer.println(deliverersBuilder);
            }
            writer.flush();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void save(T entity) {
        List<T> restaurants = findAll();
        if(Optional.ofNullable(entity.getId()).isEmpty()) {
            entity.setId(generateNewId());
        }
        restaurants.add(entity);
        save(restaurants);
    }

    private Long generateNewId() {
        return findAll().stream().map(i -> i.getId())
                .max((i1, i2) -> i1.compareTo(i2)).orElse(0l) + 1;
    }
}
