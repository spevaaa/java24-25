package hr.javafx.restaurant.spevec7.restaurant.repository;

import hr.javafx.restaurant.spevec7.restaurant.model.Entity;

import java.util.List;

public abstract class AbstractRepository<T extends Entity> {
    public abstract List<T> findAll();
    public abstract T findById(Long id);
    public abstract void save(List<T> entities);
    public abstract void save(T entity);
}
