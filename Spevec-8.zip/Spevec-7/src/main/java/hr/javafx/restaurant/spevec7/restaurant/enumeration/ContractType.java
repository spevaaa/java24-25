package hr.javafx.restaurant.spevec7.restaurant.enumeration;

import hr.javafx.restaurant.spevec7.restaurant.model.Entity;

public enum ContractType {
    FULL_TIME("FULL_TIME"),
    PART_TIME("PART_TIME");

    private String contractType;

    ContractType(String contractType) {
        this.contractType = contractType;
    }

    public String getContractType() {
        return contractType;
    }

    public void setContractType(String contractType) {
        this.contractType = contractType;
    }
}
