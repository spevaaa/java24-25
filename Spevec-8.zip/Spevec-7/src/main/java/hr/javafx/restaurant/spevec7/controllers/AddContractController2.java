package hr.javafx.restaurant.spevec7.controllers;

import hr.javafx.restaurant.spevec7.main.Main;
import hr.javafx.restaurant.spevec7.restaurant.model.DataHolder;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;

public class AddContractController2 {
    @FXML
    public ListView<String> fileListView;


    public void initialize() {
        fileListView.getItems().clear();
        fileListView.getItems().addAll(DataHolder.files);
    }

    public void chooseFile(){
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choose a file");
        File selectedFile = fileChooser.showOpenDialog(fileListView.getScene().getWindow());
        if (selectedFile != null) {
            String filePath = selectedFile.getAbsolutePath();
            DataHolder.files.add(filePath);
            fileListView.getItems().add(filePath);
        }

    }

    public void backStep(){

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec7/addContract.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void nextStep(){

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec7/addContract3.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
