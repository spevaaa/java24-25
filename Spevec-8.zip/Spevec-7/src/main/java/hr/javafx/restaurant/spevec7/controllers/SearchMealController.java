package hr.javafx.restaurant.spevec7.controllers;

import hr.javafx.restaurant.spevec7.restaurant.model.Category;
import hr.javafx.restaurant.spevec7.restaurant.model.Ingredient;
import hr.javafx.restaurant.spevec7.restaurant.model.Meal;
import hr.javafx.restaurant.spevec7.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.CategoriesRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.MealRepository;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

public class SearchMealController {
    @FXML
    private TextField mealNameTextField;
    @FXML
    private TableView<Meal> mealTableView;
    @FXML
    private TableColumn<Meal, String> mealIdColumn;
    @FXML
    private TableColumn<Meal, String> mealNameColumn;
    @FXML
    private TableColumn<Meal, String> mealCategoryColumn;
    @FXML
    private TableColumn<Meal, String> mealIngredientsColumn;
    @FXML
    private TableColumn<Meal, String> mealPriceColumn;
    @FXML
    private ComboBox<String> mealCategoryComboBox;
    @FXML
    private TextField ingredientTextField;
    @FXML
    private TextField mealPriceFrom;
    @FXML
    private TextField mealPriceTo;

    private AbstractRepository<Meal> mealRepository = new MealRepository();
    private AbstractRepository<Category> categoryRepository = new CategoriesRepository();
    private List<Category> categories = categoryRepository.findAll();
    private ObservableList<String> categoryObservableList = FXCollections.observableArrayList(categories.stream().map(Category::getName).collect(Collectors.toList()));


    public void initialize() {
        mealIdColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getId())));

        mealNameColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getName()));

        mealCategoryColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getCategory().getName()));

        mealIngredientsColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(
                        cellData.getValue().getIngredients().stream()
                                .map(Ingredient::getName)
                                .collect(Collectors.joining(", "))
                ));

        mealPriceColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(String.valueOf(cellData.getValue().getPrice())));

        mealCategoryComboBox.setItems(categoryObservableList);
    }

    public void filterMeals() {
        List<Meal> mealList = mealRepository.findAll();

        String mealName = mealNameTextField.getText();
        if(!mealName.isEmpty()) {
            mealList = mealList.stream()
                    .filter(meal -> meal.getName().toLowerCase().contains(mealName.toLowerCase()))
                    .collect(Collectors.toList());
        }

        String selectedCategory = mealCategoryComboBox.getValue();
        if (selectedCategory != null && !selectedCategory.isEmpty()) {
            mealList = mealList.stream()
                    .filter(meal -> meal.getIngredients().stream()
                            .anyMatch(ingredient -> ingredient.getCategory().getName().equalsIgnoreCase(selectedCategory))
                    )
                    .collect(Collectors.toList());
        }

        String ingredientName = ingredientTextField.getText();
        if(!ingredientName.isEmpty()) {
            mealList = mealList.stream()
                    .filter(meal -> meal.getIngredients().stream()
                            .anyMatch(ingredient -> ingredient.getName().toLowerCase().contains(ingredientName.toLowerCase())))
                    .collect(Collectors.toList());
        }

        if(!mealPriceFrom.getText().isEmpty()) {
            BigDecimal mealFromPrice = new BigDecimal(mealPriceFrom.getText());
            mealList = mealList.stream()
                    .filter(meal -> meal.getPrice().compareTo(mealFromPrice) >= 0)
                    .collect(Collectors.toList());
        }

        if(!mealPriceTo.getText().isEmpty()) {
            BigDecimal beverageToPrice = new BigDecimal(mealPriceTo.getText());
            mealList = mealList.stream()
                    .filter(meal -> meal.getPrice().compareTo(beverageToPrice) <= 0)
                    .collect(Collectors.toList());
        }

        ObservableList<Meal> mealObservableList = FXCollections.observableList(mealList);
        mealTableView.setItems(mealObservableList);
    }
}
