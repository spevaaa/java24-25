package hr.javafx.restaurant.spevec7.restaurant.model;

import java.util.Scanner;

public class Address extends Entity {
    private String street, houseNumber, city, postalCode;

    public Address(Long id, String street, String houseNumber, String city, String postalCode) {
        super(id);
        this.street = street;
        this.houseNumber = houseNumber;
        this.city = city;
        this.postalCode = postalCode;
    }

    public Address(String street, String houseNumber, String city, String postalCode) {
        this.street = street;
        this.houseNumber = houseNumber;
        this.city = city;
        this.postalCode = postalCode;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public static class Builder {
        private Long id;
        private String street, houseNumber, city, postalCode;

        public Builder(long id) {
            this.id = id;
        }

        public Builder inStreet(String street) {
            this.street = street;
            return this;
        }

        public Builder atHouseNumber(String houseNumber) {
            this.houseNumber = houseNumber;
            return this;
        }

        public Builder inCity(String city) {
            this.city = city;
            return this;
        }

        public Builder withPostalCode(String postalCode) {
            this.postalCode = postalCode;
            return this;
        }

        public Address build() {
            Address address = new Address();

            address.setId(this.id);
            address.setStreet(this.street);
            address.setHouseNumber(this.houseNumber);
            address.setCity(this.city);
            address.setPostalCode(this.postalCode);

            return address;
        }
    }

    private Address() {}
}
