package hr.javafx.restaurant.spevec7.restaurant.repository;

import hr.javafx.restaurant.spevec7.restaurant.model.Deliverer;
import hr.javafx.restaurant.spevec7.restaurant.model.Meal;
import hr.javafx.restaurant.spevec7.restaurant.model.Order;
import hr.javafx.restaurant.spevec7.restaurant.model.Restaurant;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class OrderRepository <T extends Order> extends AbstractRepository<T> {
    private static final String ORDERS_FILE_PATH = "dat/orders.txt";
    private static final Integer NUMBER_OF_ROWS_PER_ORDER = 5;

    @Override
    public List<T> findAll() {
        List<T> orders = new ArrayList<>();
        RestaurantRepository restaurantRepository = new RestaurantRepository();
        MealRepository mealRepository = new MealRepository();
        DelivererRepository delivererRepository = new DelivererRepository();

        try (Stream<String> stream = Files.lines(Path.of(ORDERS_FILE_PATH))) {
            List<String> fileRows = stream.collect(Collectors.toList());

            for (Integer recordNumber = 0; recordNumber < (fileRows.size() / NUMBER_OF_ROWS_PER_ORDER); recordNumber++) {
                Long id = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_ORDER));

                Long restaurantId = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_ORDER + 1));
                Restaurant restaurant = restaurantRepository.findById(restaurantId);

                String mealsIds = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_ORDER + 2);
                List<Meal> meals = Arrays.stream(mealsIds.split(","))
                        .map(idString -> Long.parseLong(idString))
                        .map(idLong -> mealRepository.findById(idLong))
                        .collect(Collectors.toList());

                Long delivererId = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_ORDER + 3));
                Deliverer deliverer = delivererRepository.findById(delivererId);

                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy. HH:mm");
                LocalDateTime deliveryDateAndTime = LocalDateTime.parse(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_ORDER + 4), dateTimeFormatter);

                Order order = new Order(id, restaurant, meals, deliverer, deliveryDateAndTime);
                orders.add((T) order);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return orders;
    }

    @Override
    public T findById(Long id) {
        return findAll().stream().filter(entity -> entity.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public void save(List<T> entities) {
        try (PrintWriter writer = new PrintWriter(ORDERS_FILE_PATH)) {
            for (T entity : entities) {
                writer.println(entity.getId());
                writer.println(entity.getRestaurant().getId());

                StringBuilder mealBuilder = new StringBuilder();
                for(Meal meal : entity.getMeals()) {
                    mealBuilder = mealBuilder.append(meal.getId()).append(",");
                }
                writer.println(mealBuilder);

                writer.println(entity.getDeliverer().getId());
                writer.println(entity.getDeliveryDateAndTime());
            }
            writer.flush();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void save(T entity) {
        List<T> restaurants = findAll();
        if(Optional.ofNullable(entity.getId()).isEmpty()) {
            entity.setId(generateNewId());
        }
        restaurants.add(entity);
        save(restaurants);
    }

    private Long generateNewId() {
        return findAll().stream().map(i -> i.getId())
                .max((i1, i2) -> i1.compareTo(i2)).orElse(0l) + 1;
    }
}
