package hr.javafx.restaurant.spevec7.controllers;

import hr.javafx.restaurant.spevec7.main.Main;
import hr.javafx.restaurant.spevec7.restaurant.model.*;
import hr.javafx.restaurant.spevec7.restaurant.repository.AbstractRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.ChefRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.ContractRepository;
import hr.javafx.restaurant.spevec7.restaurant.repository.DelivererRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class AddDelivererController {
    @FXML
    private TextField addDelivererFirstNameTextField;
    @FXML
    private TextField addDelivererLastNameTextField;
    @FXML
    private ComboBox<Long> contractIdComboBox;
    @FXML
    private TextField addDelivererBonusTextField;

    private AbstractRepository<Deliverer> delivererRepository = new DelivererRepository<>();

    private AbstractRepository<Contract> contractRepository = new ContractRepository<>();
    private List<Contract> contractList = contractRepository.findAll();
    private ObservableList<Long> contractIdObservableList = FXCollections.observableArrayList(contractList.stream().map(Contract::getId).collect(Collectors.toList()));

    public void initialize() {
        contractIdComboBox.setItems(contractIdObservableList);
    }

    public void addDeliverer() {
        String firstName = addDelivererFirstNameTextField.getText();
        String lastName = addDelivererLastNameTextField.getText();

        Long contractID = contractIdComboBox.getValue();
        Contract contract = contractList.stream().filter(c -> c.getId().equals(contractID)).findFirst().get();

        Bonus bonus = new Bonus(new BigDecimal(addDelivererBonusTextField.getText()));

        Deliverer deliverer = new Deliverer(firstName, lastName, contract, bonus);

        delivererRepository.save(deliverer);

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec7/showDeliverers.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
