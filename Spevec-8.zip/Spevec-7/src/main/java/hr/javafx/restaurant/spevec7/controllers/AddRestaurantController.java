package hr.javafx.restaurant.spevec7.controllers;

import hr.javafx.restaurant.spevec7.main.Main;
import hr.javafx.restaurant.spevec7.restaurant.model.*;
import hr.javafx.restaurant.spevec7.restaurant.repository.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class AddRestaurantController {
    @FXML
    private TextField restaurantNameTextField;
    @FXML
    private ComboBox<String> restaurantAddressComboBox;
    @FXML
    private ListView<String> mealsListView;
    @FXML
    private ListView<String> chefsListView;
    @FXML
    private ListView<String> deliverersListView;
    @FXML
    private ListView<String> waitersListView;

    public AbstractRepository<Restaurant> restaurantRepository = new RestaurantRepository();

    public AbstractRepository<Address> addressRepository = new AddressRepository<>();
    List<Address> addressList = addressRepository.findAll();
    ObservableList<String> addressObservableList = FXCollections.observableArrayList(addressList.stream().map(Address::getStreet).collect(Collectors.toList()));

    private AbstractRepository<Meal> mealRepository = new MealRepository<>();
    private ObservableList<String> mealObservableList;
    private AbstractRepository<Chef> chefRepository = new ChefRepository<>();
    private ObservableList<String> chefObservableList;
    private AbstractRepository<Deliverer> delivererRepository = new DelivererRepository();
    private ObservableList<String> delivererObservableList;
    private AbstractRepository<Waiter> waiterRepository = new WaiterRepository();
    private ObservableList<String> waiterObservableList;


    public void initialize() {
        restaurantAddressComboBox.setItems(addressObservableList);

        List<Meal> mealList = mealRepository.findAll();
        mealObservableList = FXCollections.observableArrayList(mealList.stream().map(Meal::getName).collect(Collectors.toSet()));
        mealsListView.setItems(mealObservableList);

        List<Chef> chefList = chefRepository.findAll();
        chefObservableList = FXCollections.observableArrayList(chefList.stream().map(Chef::getFirstName).collect(Collectors.toSet()));
        chefsListView.setItems(chefObservableList);

        List<Deliverer> delivererList = delivererRepository.findAll();
        delivererObservableList = FXCollections.observableArrayList(delivererList.stream().map(Deliverer::getFirstName).collect(Collectors.toSet()));
        deliverersListView.setItems(delivererObservableList);

        List<Waiter> waiterList = waiterRepository.findAll();
        waiterObservableList = FXCollections.observableArrayList(waiterList.stream().map(Waiter::getFirstName).collect(Collectors.toSet()));
        waitersListView.setItems(waiterObservableList);


        mealsListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        chefsListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        deliverersListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        waitersListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    public void addRestaurant() {
        String restaurantName = restaurantNameTextField.getText();
        String restaurantStreet = restaurantAddressComboBox.getValue();
        Address address = addressList.stream().filter(address1 -> address1.getStreet().equals(restaurantStreet)).findFirst().orElse(null);

        Set<Meal> mealSet = mealsListView.getSelectionModel()
                .getSelectedItems()
                .stream()
                .map(selectedName -> mealRepository.findAll().stream()
                        .filter(meal -> meal.getName().equals(selectedName))
                        .findFirst()
                        .orElse(null))
                .filter(meal -> meal != null)
                .collect(Collectors.toSet());


        Set<Chef> chefSet = chefsListView.getSelectionModel()
                .getSelectedItems()
                .stream()
                .map(selectedName -> chefRepository.findAll().stream()
                        .filter(chef -> chef.getFirstName().equals(selectedName))
                        .findFirst()
                        .orElse(null))
                .filter(chef -> chef != null)
                .collect(Collectors.toSet());

        Set<Deliverer> delivererSet = deliverersListView.getSelectionModel()
                .getSelectedItems()
                .stream()
                .map(selectedName -> delivererRepository.findAll().stream()
                        .filter(deliverer -> deliverer.getFirstName().equals(selectedName))
                        .findFirst()
                        .orElse(null))
                .filter(deliverer -> deliverer != null)
                .collect(Collectors.toSet());

        Set<Waiter> waiterSet = waitersListView.getSelectionModel()
                .getSelectedItems()
                .stream()
                .map(selectedName -> waiterRepository.findAll().stream()
                        .filter(waiter -> waiter.getFirstName().equals(selectedName))
                        .findFirst()
                        .orElse(null))
                .filter(waiter -> waiter != null)
                .collect(Collectors.toSet());

        Restaurant restaurant = new Restaurant(restaurantName, address, mealSet, chefSet, waiterSet, delivererSet);
        restaurantRepository.save(restaurant);


        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/hr/javafx/restaurant/spevec7/showRestaurants.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 500);
            Main.getStage().setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
