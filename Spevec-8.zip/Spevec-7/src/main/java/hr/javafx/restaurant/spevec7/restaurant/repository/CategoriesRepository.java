package hr.javafx.restaurant.spevec7.restaurant.repository;

import hr.javafx.restaurant.spevec7.restaurant.model.Category;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CategoriesRepository<T extends Category> extends AbstractRepository<T> {
    private static final String CATEGORIES_FILE_PATH = "dat/categories.txt";
    private static final Integer NUMBER_OF_ROWS_PER_CATEGORY = 3;

    @Override
    public List<T> findAll() {
        List<T> categories = new ArrayList<>();

        try (Stream<String> stream = Files.lines(Path.of(CATEGORIES_FILE_PATH))) {
            List<String> fileRows = stream.collect(Collectors.toList());

            for (Integer recordNumber = 0; recordNumber < (fileRows.size() / NUMBER_OF_ROWS_PER_CATEGORY); recordNumber++) {
                Long id = Long.parseLong(fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_CATEGORY));
                String name = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_CATEGORY + 1);
                String description = fileRows.get(recordNumber * NUMBER_OF_ROWS_PER_CATEGORY + 2);

                Category category = new Category(id, name, description);
                categories.add((T) category);
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return categories;
    }

    @Override
    public T findById(Long id) {
        return findAll().stream().filter(entity -> entity.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public void save(List<T> entities) {
        try (PrintWriter writer = new PrintWriter(CATEGORIES_FILE_PATH)) {
            for (T entity : entities) {
                writer.println(entity.getId());
                writer.println(entity.getName());
                writer.println(entity.getDescription());
            }
            writer.flush();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void save(T entity) {
        List<T> categories = findAll();
        if(Optional.ofNullable(entity.getId()).isEmpty()) {
            entity.setId(generateNewId());
        }
        categories.add(entity);
        save(categories);
    }

    private Long generateNewId() {
        return findAll().stream().map(i -> i.getId())
                .max((i1, i2) -> i1.compareTo(i2)).orElse(0l) + 1;
    }
}
